
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Layout from '@/components/Layout';
import Dashboard from '@/pages/Dashboard';
import Inbox from '@/pages/Inbox';
import Contacts from '@/pages/Contacts';
import Broadcasts from '@/pages/Broadcasts';
import Chatbots from '@/pages/Chatbots';
import Templates from '@/pages/Templates';
import Analytics from '@/pages/Analytics';
import Team from '@/pages/Team';
import Settings from '@/pages/Settings';
import Profile from '@/pages/Profile';
import Login from '@/pages/Login';
import Signup from '@/pages/Signup';
import ProtectedRoute from '@/components/ProtectedRoute';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';
import { Toaster } from '@/components/ui/toaster';
import WhatsAppSetup from '@/pages/WhatsAppSetup';
import WebhookListener from '@/components/WebhookListener';

const AppRoutes = () => {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route 
        path="/*"
        element={
          <ProtectedRoute>
            <Layout>
              <WebhookListener />
              <Routes>
                <Route path="/" element={<Navigate to="/dashboard" replace />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/inbox" element={<Inbox />} />
                <Route path="/contacts" element={<Contacts />} />
                <Route path="/broadcasts" element={<Broadcasts />} />
                <Route path="/chatbots" element={<Chatbots />} />
                <Route path="/templates" element={<Templates />} />
                <Route path="/analytics" element={<Analytics />} />
                <Route path="/team" element={<Team />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/whatsapp-setup" element={<WhatsAppSetup />} />
              </Routes>
            </Layout>
          </ProtectedRoute>
        } 
      />
    </Routes>
  );
};


function App() {
  return (
    <>
      <Helmet>
        <title>Wabista - The Ultimate WhatsApp Business Platform</title>
        <meta name="description" content="Complete WhatsApp Business API platform with inbox management, broadcasts, chatbots, analytics and team collaboration tools." />
      </Helmet>
      <Router>
        <AuthProvider>
          <AppRoutes />
          <Toaster />
        </AuthProvider>
      </Router>
    </>
  );
}

export default App;
