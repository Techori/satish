
import { API_CONFIG, getAuthToken } from '@/config/api';
import { supabase } from '@/lib/customSupabaseClient';

class ApiService {
  constructor() {
    this.baseUrl = API_CONFIG.BASE_URL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const token = getAuthToken();
    
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...options.headers,
    };

    const config = {
      ...options,
      headers,
    };

    try {
      const response = await fetch(url, config);
      
      if (response.status === 401) {
        // Handle unauthorized access (e.g., redirect to login)
        this.handleUnauthorized();
        throw new Error('Unauthorized');
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP Error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('API Request Failed:', error);
      throw error;
    }
  }

  handleUnauthorized() {
    // Dispatch event or redirect
    window.dispatchEvent(new CustomEvent('auth:unauthorized'));
  }

  // --- WhatsApp Specific Methods ---

  async sendWhatsAppMessage(phoneNumber, content, type = 'text') {
    // For now, we use Supabase directly as the "backend"
    // In a real backend scenario, this would call this.request(API_CONFIG.ENDPOINTS.WHATSAPP.SEND_MESSAGE, ...)
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('messages')
        .insert({
          user_id: user.id,
          content: content,
          is_from_user: false,
          status: 'sending',
          // In a real scenario, we'd resolve contact_id from phoneNumber
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to send WhatsApp message:', error);
      throw error;
    }
  }

  async getWhatsAppStatus() {
    return this.request(API_CONFIG.ENDPOINTS.WHATSAPP.STATUS, { method: 'GET' });
  }

  async updateWebhookUrl(url) {
    return this.request(API_CONFIG.ENDPOINTS.WHATSAPP.WEBHOOKS, {
      method: 'PUT',
      body: JSON.stringify({ url })
    });
  }

  // --- Admin Methods ---
  
  async getUsers(page = 1, limit = 10) {
    return this.request(`${API_CONFIG.ENDPOINTS.ADMIN.USERS}?page=${page}&limit=${limit}`);
  }
  
  async updateUserRole(userId, role) {
    return this.request(`${API_CONFIG.ENDPOINTS.ADMIN.USERS}/${userId}/role`, {
      method: 'PUT',
      body: JSON.stringify({ role })
    });
  }
}

export const apiService = new ApiService();
