
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

class WebhookService {
  constructor() {
    this.channels = {};
    this.listeners = new Set();
  }

  /**
   * Log a webhook event to the database
   */
  async logEvent(eventType, payload, status = 'processed', errorMessage = null) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.from('webhook_logs').insert({
        user_id: user.id,
        event_type: eventType,
        payload,
        status,
        error_message: errorMessage
      });
    } catch (error) {
      console.error('Failed to log webhook event:', error);
    }
  }

  /**
   * Subscribe to real-time changes for a specific user
   */
  subscribeToUserEvents(userId, onEvent) {
    if (!userId) return () => {};

    const channelId = `room:${userId}`;
    
    // If channel exists, just add listener
    if (this.channels[channelId]) {
      this.listeners.add(onEvent);
      return () => this.listeners.delete(onEvent);
    }

    const channel = supabase
      .channel(channelId)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages',
          filter: `user_id=eq.${userId}`
        },
        async (payload) => {
          await this.handleMessageEvent(payload, onEvent);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'contacts',
          filter: `user_id=eq.${userId}`
        },
        async (payload) => {
          await this.handleContactEvent(payload, onEvent);
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('🔌 Real-time connection established');
        }
      });

    this.channels[channelId] = channel;
    this.listeners.add(onEvent);

    return () => {
      this.listeners.delete(onEvent);
      if (this.listeners.size === 0 && this.channels[channelId]) {
        supabase.removeChannel(this.channels[channelId]);
        delete this.channels[channelId];
      }
    };
  }

  async handleMessageEvent(payload, onEvent) {
    try {
      const { eventType, new: newRecord, old: oldRecord } = payload;
      
      // Prepare event data
      const eventData = {
        type: eventType === 'INSERT' ? 'MESSAGE_RECEIVED' : 'MESSAGE_UPDATED',
        data: newRecord,
        timestamp: new Date().toISOString()
      };

      // Log the event
      await this.logEvent('message', eventData, 'processed');

      // Notify listeners
      this.notifyListeners(eventData);

    } catch (error) {
      console.error('Error processing message webhook:', error);
      await this.logEvent('message_error', payload, 'failed', error.message);
    }
  }

  async handleContactEvent(payload, onEvent) {
    try {
      const eventData = {
        type: 'CONTACT_UPDATED',
        data: payload.new,
        timestamp: new Date().toISOString()
      };

      await this.logEvent('contact', eventData, 'processed');
      this.notifyListeners(eventData);

    } catch (error) {
      console.error('Error processing contact webhook:', error);
      await this.logEvent('contact_error', payload, 'failed', error.message);
    }
  }

  notifyListeners(data) {
    this.listeners.forEach(listener => {
      try {
        listener(data);
      } catch (e) {
        console.error('Error in webhook listener:', e);
      }
    });
  }
}

export const webhookService = new WebhookService();
