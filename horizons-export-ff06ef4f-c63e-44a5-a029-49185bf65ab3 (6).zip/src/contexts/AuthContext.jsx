import React, { createContext, useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('whatsappApiUser');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error("Failed to parse user from localStorage", error);
      localStorage.removeItem('whatsappApiUser');
    } finally {
      setLoading(false);
    }
  }, []);

  const login = (email, password) => {
    // In a real app, you'd validate against a backend.
    // Here, we'll check against localStorage or create a new user.
    const storedUsers = JSON.parse(localStorage.getItem('whatsappApiUsers') || '{}');
    if (storedUsers[email] && storedUsers[email].password === password) {
      const userData = { email, name: storedUsers[email].name };
      localStorage.setItem('whatsappApiUser', JSON.stringify(userData));
      setUser(userData);
      navigate('/dashboard');
      return true;
    }
    return false;
  };

  const signup = (name, email, password) => {
    const storedUsers = JSON.parse(localStorage.getItem('whatsappApiUsers') || '{}');
    if (storedUsers[email]) {
      return { success: false, message: 'User with this email already exists.' };
    }
    
    const newUser = { name, email, password };
    storedUsers[email] = newUser;
    localStorage.setItem('whatsappApiUsers', JSON.stringify(storedUsers));
    
    localStorage.setItem('whatsappApiUser', JSON.stringify({ name, email }));
    setUser({ name, email });
    navigate('/dashboard');
    return { success: true };
  };

  const logout = () => {
    localStorage.removeItem('whatsappApiUser');
    setUser(null);
    navigate('/login');
  };

  const value = { user, loading, login, signup, logout };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};