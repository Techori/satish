// Configuration for API endpoints and environment variables
// In a real deployment, these would come from import.meta.env
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || 'https://api.whatsbiz.com/v1',
  TIMEOUT: 15000,
  RETRY_ATTEMPTS: 3,
  ENDPOINTS: {
    AUTH: {
      LOGIN: '/auth/login',
      REGISTER: '/auth/register',
      REFRESH: '/auth/refresh',
      LOGOUT: '/auth/logout',
    },
    WHATSAPP: {
      SEND_MESSAGE: '/whatsapp/messages',
      TEMPLATES: '/whatsapp/templates',
      WEBHOOKS: '/whatsapp/webhooks',
      CONNECT: '/whatsapp/connect',
      STATUS: '/whatsapp/status',
    },
    CONTACTS: '/contacts',
    BROADCASTS: '/broadcasts',
    ANALYTICS: '/analytics',
    ADMIN: {
      USERS: '/admin/users',
      ROLES: '/admin/roles',
      SETTINGS: '/admin/settings',
    }
  }
};

export const getAuthToken = () => {
  try {
    // Try to get from Supabase session first
    const session = localStorage.getItem('sb-access-token');
    if (session) return session;
    
    // Fallback to local storage for other auth methods
    return localStorage.getItem('auth_token');
  } catch (e) {
    return null;
  }
};