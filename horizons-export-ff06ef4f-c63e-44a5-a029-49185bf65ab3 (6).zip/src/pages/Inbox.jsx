
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  MoreVertical, 
  Phone, 
  Video, 
  Paperclip, 
  Smile, 
  Mic, 
  Send,
  Check,
  CheckCheck,
  Clock,
  MessageSquare,
  User,
  RefreshCw,
  AlertCircle,
  Trash2,
  StopCircle,
  Play,
  Pause,
  ArrowLeft
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { cn } from '@/lib/utils';
import { webhookService } from '@/services/webhookService';

// Simple Audio Player Component
const AudioMessage = ({ src }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const setAudioData = () => {
      setDuration(audio.duration);
    };

    const setAudioTime = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('loadedmetadata', setAudioData);
    audio.addEventListener('timeupdate', setAudioTime);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('loadedmetadata', setAudioData);
      audio.removeEventListener('timeupdate', setAudioTime);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  const togglePlay = () => {
    if (audioRef.current.paused) {
      audioRef.current.play();
      setIsPlaying(true);
    } else {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  const formatTime = (time) => {
    if (isNaN(time)) return "0:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center gap-3 min-w-[200px] p-1">
      <button 
        onClick={togglePlay}
        className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600 transition-colors"
        type="button"
      >
        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
      </button>
      <div className="flex-1">
        <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
          <div 
            className="h-full bg-green-500 transition-all duration-100"
            style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
          />
        </div>
        <div className="flex justify-between mt-1">
          <span className="text-[10px] text-gray-500 font-medium">{formatTime(currentTime)}</span>
          <span className="text-[10px] text-gray-500 font-medium">{formatTime(duration)}</span>
        </div>
      </div>
      <audio ref={audioRef} src={src} preload="metadata" className="hidden" />
    </div>
  );
};

const Inbox = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [contacts, setContacts] = useState([]);
  const [activeContact, setActiveContact] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);
  const [filter, setFilter] = useState('');
  
  // Mobile view state
  const [showMobileChat, setShowMobileChat] = useState(false);

  // Voice Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const timerIntervalRef = useRef(null);

  // Fetch initial data
  const fetchInitialData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    
    try {
      const { data: contactsData, error: contactsError } = await supabase
        .from('contacts')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (contactsError) throw contactsError;

      const contactsWithMessages = await Promise.all(contactsData.map(async (contact) => {
        const { data: lastMsg } = await supabase
          .from('messages')
          .select('*')
          .eq('contact_id', contact.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .single();
        
        return {
          ...contact,
          lastMessage: lastMsg || null,
          unreadCount: 0
        };
      }));

      const sortedContacts = contactsWithMessages.sort((a, b) => {
        const timeA = a.lastMessage ? new Date(a.lastMessage.created_at) : new Date(a.created_at);
        const timeB = b.lastMessage ? new Date(b.lastMessage.created_at) : new Date(b.created_at);
        return timeB - timeA;
      });

      setContacts(sortedContacts);
      if (sortedContacts.length > 0 && !activeContact) {
        setActiveContact(sortedContacts[0]);
        // Don't set showMobileChat(true) here to respect list-first view on mobile
      }

    } catch (error) {
      console.error('Error fetching inbox data:', error);
      toast({ title: "Error", description: "Failed to load conversations", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [user, activeContact, toast]);

  useEffect(() => {
    fetchInitialData();
  }, []);

  // Fetch messages for active contact
  useEffect(() => {
    const fetchMessages = async () => {
      if (!activeContact || !user) return;
      
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('contact_id', activeContact.id)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error fetching messages:', error);
      } else {
        setMessages(data);
        scrollToBottom();
      }
    };

    fetchMessages();
  }, [activeContact, user]);

  const scrollToBottom = () => {
    setTimeout(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }
    }, 100);
  };

  // Real-time subscription
  useEffect(() => {
    if (!user) return;

    const handleEvent = (event) => {
      if (event.type === 'MESSAGE_RECEIVED' || event.type === 'MESSAGE_UPDATED') {
        const newMessage = event.data;
        
        if (activeContact && newMessage.contact_id === activeContact.id) {
          setMessages(prev => {
            const exists = prev.find(m => m.id === newMessage.id);
            if (exists) {
              return prev.map(m => m.id === newMessage.id ? newMessage : m);
            }
            return [...prev, newMessage];
          });
          scrollToBottom();
        }

        setContacts(prevContacts => {
          return prevContacts.map(c => {
            if (c.id === newMessage.contact_id) {
              return { ...c, lastMessage: newMessage };
            }
            return c;
          }).sort((a, b) => {
             const timeA = a.id === newMessage.contact_id ? new Date(newMessage.created_at) : (a.lastMessage ? new Date(a.lastMessage.created_at) : new Date(a.created_at));
             const timeB = b.id === newMessage.contact_id ? new Date(newMessage.created_at) : (b.lastMessage ? new Date(b.lastMessage.created_at) : new Date(b.created_at));
             return timeB - timeA;
          });
        });
      }
    };

    const unsubscribe = webhookService.subscribeToUserEvents(user.id, handleEvent);
    return () => unsubscribe();
  }, [user, activeContact]);

  // --- Audio Recording Logic ---

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingDuration(0);

      timerIntervalRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);

    } catch (err) {
      console.error("Error accessing microphone:", err);
      toast({ 
        title: "Microphone Error", 
        description: "Please allow microphone access to record voice messages.",
        variant: "destructive"
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(timerIntervalRef.current);
      
      // Return a promise that resolves with the blob when 'onstop' fires
      return new Promise((resolve) => {
        mediaRecorderRef.current.onstop = () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' }); // or audio/mp3 depending on browser support
          const tracks = mediaRecorderRef.current.stream.getTracks();
          tracks.forEach(track => track.stop());
          resolve(audioBlob);
        };
      });
    }
    return Promise.resolve(null);
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      const tracks = mediaRecorderRef.current.stream.getTracks();
      tracks.forEach(track => track.stop());
    }
    setIsRecording(false);
    setRecordingDuration(0);
    clearInterval(timerIntervalRef.current);
    audioChunksRef.current = [];
  };

  const handleSendVoiceMessage = async () => {
    try {
      setSending(true);
      const audioBlob = await stopRecording();
      if (!audioBlob) return;

      // Upload to Supabase Storage
      const fileName = `${user.id}/${Date.now()}-voice.webm`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('chat-attachments')
        .upload(fileName, audioBlob, {
          contentType: 'audio/webm',
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('chat-attachments')
        .getPublicUrl(fileName);

      // Send message record
      const { data: msgData, error: msgError } = await supabase
        .from('messages')
        .insert({
          user_id: user.id,
          contact_id: activeContact.id,
          content: '🎤 Voice Message',
          message_type: 'audio',
          media_url: publicUrl,
          is_from_user: true,
          status: 'sent',
          is_welcome_message: false
        })
        .select()
        .single();

      if (msgError) throw msgError;

      setMessages(prev => [...prev, msgData]);
      setContacts(prev => prev.map(c => c.id === activeContact.id ? { ...c, lastMessage: msgData } : c));
      scrollToBottom();

    } catch (error) {
      console.error('Error sending voice message:', error);
      toast({ title: "Failed to send voice message", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  // --- End Audio Logic ---

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputMessage.trim() || !activeContact || !user) return;

    setSending(true);
    try {
      const optimisticMsg = {
        id: 'temp-' + Date.now(),
        content: inputMessage,
        message_type: 'text',
        is_from_user: true,
        status: 'sending',
        created_at: new Date().toISOString(),
        contact_id: activeContact.id,
        user_id: user.id
      };
      setMessages(prev => [...prev, optimisticMsg]);
      setInputMessage('');
      scrollToBottom();

      const { data, error } = await supabase
        .from('messages')
        .insert({
          user_id: user.id,
          contact_id: activeContact.id,
          content: optimisticMsg.content,
          message_type: 'text',
          is_from_user: true,
          status: 'sent',
          is_welcome_message: false
        })
        .select()
        .single();

      if (error) throw error;

      setMessages(prev => prev.map(m => m.id === optimisticMsg.id ? data : m));
      setContacts(prev => prev.map(c => c.id === activeContact.id ? { ...c, lastMessage: data } : c).sort((a,b) => new Date(b.created_at) - new Date(a.created_at)));

    } catch (error) {
      console.error('Send error:', error);
      toast({ title: "Failed to send", variant: "destructive" });
      setMessages(prev => prev.filter(m => !m.id.startsWith('temp-')));
    } finally {
      setSending(false);
    }
  };

  const formatTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'sending': return <Clock className="w-3 h-3 text-gray-400" />;
      case 'sent': return <Check className="w-3 h-3 text-gray-400" />;
      case 'delivered': return <CheckCheck className="w-3 h-3 text-gray-400" />;
      case 'read': return <CheckCheck className="w-3 h-3 text-blue-500" />;
      default: return <Check className="w-3 h-3 text-gray-400" />;
    }
  };

  const handleContactClick = (contact) => {
    setActiveContact(contact);
    setShowMobileChat(true);
  };

  const handleBackToContacts = () => {
    setShowMobileChat(false);
  };

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(filter.toLowerCase()) || 
    c.number.includes(filter)
  );

  return (
    <>
      <Helmet>
        <title>Inbox - WhatsApp Business Platform</title>
      </Helmet>
      <div className="h-[calc(100vh-2rem)] bg-white rounded-2xl shadow-lg overflow-hidden flex relative">
        {/* Contacts Sidebar */}
        <div className={cn(
          "w-full md:w-80 lg:w-96 h-full border-r border-gray-200 flex flex-col bg-gray-50/50",
          // Mobile Transition Styles
          "absolute inset-0 z-20 bg-white md:static md:z-auto transition-transform duration-300 ease-in-out",
          showMobileChat ? "-translate-x-full md:translate-x-0" : "translate-x-0"
        )}>
          <div className="p-4 border-b border-gray-200 bg-white">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-800">Messages</h2>
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" onClick={fetchInitialData} disabled={loading}>
                  <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
                </Button>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Search messages..." 
                className="pl-9 bg-gray-100 border-0 focus-visible:ring-1" 
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              />
            </div>
          </div>

          <ScrollArea className="flex-1">
            <div className="space-y-1 p-2">
              {filteredContacts.map((contact) => (
                <motion.div
                  key={contact.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={cn(
                    "flex items-start p-3 rounded-xl cursor-pointer transition-colors duration-200",
                    activeContact?.id === contact.id ? "bg-green-50 border border-green-100" : "hover:bg-white hover:shadow-sm"
                  )}
                  onClick={() => handleContactClick(contact)}
                >
                  <Avatar className="w-12 h-12 border-2 border-white shadow-sm">
                    <AvatarImage src={contact.avatar_url} />
                    <AvatarFallback className="bg-green-100 text-green-700">{contact.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="ml-3 flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-900 truncate">{contact.name}</h3>
                      <span className="text-xs text-gray-500 whitespace-nowrap">
                        {contact.lastMessage ? formatTime(contact.lastMessage.created_at) : ''}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 truncate mt-0.5 flex items-center">
                      {contact.lastMessage?.is_from_user && (
                        <span className="mr-1">{getStatusIcon(contact.lastMessage.status)}</span>
                      )}
                      {contact.lastMessage ? contact.lastMessage.content : <span className="italic text-gray-400">No messages yet</span>}
                    </p>
                  </div>
                </motion.div>
              ))}
              {filteredContacts.length === 0 && !loading && (
                <div className="p-8 text-center text-gray-500">
                  <User className="w-8 h-8 mx-auto mb-2 opacity-20" />
                  <p>No contacts found</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Chat Area */}
        <div className={cn(
          "flex-1 flex flex-col bg-[#efeae2] relative w-full h-full",
          // Mobile Transition Styles
          "absolute inset-0 z-30 md:static md:z-auto transition-transform duration-300 ease-in-out",
          showMobileChat ? "translate-x-0" : "translate-x-full md:translate-x-0"
        )}>
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-[0.06] pointer-events-none bg-[url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')]"></div>

          {activeContact ? (
            <>
              {/* Chat Header */}
              <div className="p-3 bg-white border-b border-gray-200 flex items-center justify-between z-10 shadow-sm">
                <div className="flex items-center">
                   {/* Back Button for Mobile */}
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="md:hidden mr-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full"
                    onClick={handleBackToContacts}
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                  <Avatar className="w-10 h-10 border border-gray-100">
                    <AvatarImage src={activeContact.avatar_url} />
                    <AvatarFallback>{activeContact.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="ml-3">
                    <h3 className="font-semibold text-gray-900">{activeContact.name}</h3>
                    <p className="text-xs text-green-600 font-medium">Online via Webhook</p>
                  </div>
                </div>
                <div className="flex items-center space-x-1">
                  <Button variant="ghost" size="icon"><Video className="w-5 h-5 text-gray-600" /></Button>
                  <Button variant="ghost" size="icon"><Phone className="w-5 h-5 text-gray-600" /></Button>
                  <Button variant="ghost" size="icon"><MoreVertical className="w-5 h-5 text-gray-600" /></Button>
                </div>
              </div>

              {/* Messages Area */}
              <div 
                className="flex-1 overflow-y-auto p-4 space-y-4 z-10"
                ref={scrollRef}
              >
                {messages.map((msg) => {
                  const isMe = msg.is_from_user;
                  return (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={msg.id}
                      className={cn(
                        "flex w-full",
                        isMe ? "justify-end" : "justify-start"
                      )}
                    >
                      <div 
                        className={cn(
                          "max-w-[85%] md:max-w-[70%] rounded-lg p-3 shadow-sm relative group",
                          isMe ? "bg-[#d9fdd3] rounded-tr-none" : "bg-white rounded-tl-none"
                        )}
                      >
                        {msg.message_type === 'audio' && msg.media_url ? (
                          <div className="min-w-[200px]">
                            <AudioMessage src={msg.media_url} />
                          </div>
                        ) : (
                          <p className="text-sm text-gray-800 leading-relaxed whitespace-pre-wrap break-words">
                            {msg.content}
                          </p>
                        )}
                        
                        <div className="flex items-center justify-end gap-1 mt-1 select-none">
                          <span className="text-[10px] text-gray-500">
                            {formatTime(msg.created_at)}
                          </span>
                          {isMe && getStatusIcon(msg.status)}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {/* Input Area */}
              <div className="p-3 bg-gray-50 border-t border-gray-200 z-10">
                {isRecording ? (
                   <div className="flex items-center justify-between max-w-5xl mx-auto bg-white p-2 rounded-2xl border border-red-200 shadow-sm animate-pulse-subtle">
                     <div className="flex items-center gap-3 text-red-500 pl-3">
                       <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                       <span className="font-mono font-medium">{formatDuration(recordingDuration)}</span>
                     </div>
                     <div className="flex gap-2">
                       <Button variant="ghost" size="icon" className="text-gray-500 hover:text-red-600 hover:bg-red-50" onClick={cancelRecording}>
                         <Trash2 className="w-5 h-5" />
                       </Button>
                       <Button 
                        className="bg-green-600 hover:bg-green-700 text-white rounded-full" 
                        size="sm" 
                        onClick={handleSendVoiceMessage}
                        disabled={sending}
                      >
                         {sending ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4 ml-1" />}
                       </Button>
                     </div>
                   </div>
                ) : (
                  <form onSubmit={handleSendMessage} className="flex items-end space-x-2 max-w-5xl mx-auto">
                    <div className="flex pb-2 space-x-1">
                      <Button type="button" variant="ghost" size="icon" className="h-10 w-10 rounded-full hover:bg-gray-200 hidden sm:inline-flex">
                        <Smile className="w-6 h-6 text-gray-500" />
                      </Button>
                      <Button type="button" variant="ghost" size="icon" className="h-10 w-10 rounded-full hover:bg-gray-200">
                        <Paperclip className="w-5 h-5 text-gray-500" />
                      </Button>
                    </div>
                    <div className="flex-1 bg-white rounded-2xl border border-gray-200 focus-within:ring-1 focus-within:ring-green-500 transition-shadow shadow-sm">
                      <Input 
                        className="border-0 bg-transparent focus-visible:ring-0 py-3 h-auto max-h-32" 
                        placeholder="Type a message" 
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                      />
                    </div>
                    <div className="pb-1">
                      {inputMessage.trim() ? (
                        <Button 
                          type="submit" 
                          className="rounded-full w-10 h-10 p-0 bg-green-600 hover:bg-green-700 shadow-md transition-transform active:scale-95"
                          disabled={sending}
                        >
                          <Send className="w-5 h-5 text-white ml-0.5" />
                        </Button>
                      ) : (
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="icon" 
                          className="rounded-full w-10 h-10 p-0 hover:bg-gray-200"
                          onClick={startRecording}
                        >
                          <Mic className="w-6 h-6 text-gray-500" />
                        </Button>
                      )}
                    </div>
                  </form>
                )}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-gray-500 z-10">
               {/* Mobile specific helper */}
               <div className="md:hidden flex flex-col items-center animate-pulse mb-6">
                  <ArrowLeft className="w-6 h-6 text-green-500 mb-2" />
                  <p className="text-sm text-green-600 font-medium">Swipe right or tap Back to see contacts</p>
               </div>

              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
                <MessageSquare className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Welcome to WhatsApp Inbox</h3>
              <p className="max-w-md text-gray-500 mb-8">
                Select a conversation from the sidebar to start messaging. Incoming messages will appear here in real-time.
              </p>
              <div className="flex gap-2 text-xs bg-yellow-50 text-yellow-700 px-4 py-2 rounded-full border border-yellow-200">
                <AlertCircle className="w-4 h-4" />
                Webhook listeners active
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Inbox;
