
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, 
  Plus, 
  Search, 
  MoreHorizontal, 
  Edit, 
  Trash2, 
  Upload, 
  ArrowUpDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import ImportContactsDialog from '@/components/contacts/ImportContactsDialog';

const getInitials = (name) => {
  if (!name) return 'U';
  const names = name.split(' ');
  if (names.length > 1) {
    return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
  }
  return name.substring(0, 2).toUpperCase();
};

const Contacts = () => {
  const [contacts, setContacts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [contactToDelete, setContactToDelete] = useState(null);
  const [formData, setFormData] = useState({ name: '', number: '', avatar_url: '' });
  const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'ascending' });
  const { toast } = useToast();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);

  const fetchContacts = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('contacts')
      .select('*')
      .eq('user_id', user.id);
    
    if (error) {
      console.error('Error fetching contacts:', error);
      toast({ title: 'Error', description: 'Could not fetch contacts.', variant: 'destructive' });
    } else {
      setContacts(data);
    }
    setLoading(false);
  }, [user, toast]);

  useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    if (!user) return;

    const contactData = { ...formData, user_id: user.id };

    if (editingContact) {
      // Update
      const { error } = await supabase
        .from('contacts')
        .update(contactData)
        .eq('id', editingContact.id);
      
      if (error) {
        console.error('Error updating contact:', error);
        toast({ title: 'Error', description: 'Failed to update contact.', variant: 'destructive' });
      } else {
        toast({ title: 'Success', description: 'Contact updated successfully.' });
        await fetchContacts();
      }
    } else {
      // Create
      const { error } = await supabase
        .from('contacts')
        .insert(contactData);

      if (error) {
        console.error('Error creating contact:', error);
        toast({ title: 'Error', description: 'Failed to create contact.', variant: 'destructive' });
      } else {
        toast({ title: 'Success', description: 'Contact created successfully.' });
        await fetchContacts();
      }
    }

    closeForm();
  };
  
  const openForm = (contact = null) => {
    setEditingContact(contact);
    setFormData(contact ? { name: contact.name, number: contact.number, avatar_url: contact.avatar_url || '' } : { name: '', number: '', avatar_url: '' });
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
    setEditingContact(null);
    setFormData({ name: '', number: '', avatar_url: '' });
  };
  
  const handleDeleteContact = async () => {
    if (!contactToDelete) return;

    const { error: messageError } = await supabase
        .from('messages')
        .delete()
        .eq('contact_id', contactToDelete.id);
    
    if (messageError) {
        console.error('Error deleting messages for contact:', messageError);
        toast({ title: 'Error', description: 'Failed to delete associated messages.', variant: 'destructive' });
        setContactToDelete(null);
        return;
    }

    const { error } = await supabase
      .from('contacts')
      .delete()
      .eq('id', contactToDelete.id);
      
    if (error) {
      console.error('Error deleting contact:', error);
      toast({ title: 'Error', description: 'Failed to delete contact.', variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Contact deleted successfully.' });
      setContacts(contacts.filter(c => c.id !== contactToDelete.id));
    }
    setContactToDelete(null);
  };
  
  const handleSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const filteredAndSortedContacts = useMemo(() => {
    let sortableItems = [...contacts].filter(contact =>
      contact.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    sortableItems.sort((a, b) => {
      if (a[sortConfig.key] < b[sortConfig.key]) {
        return sortConfig.direction === 'ascending' ? -1 : 1;
      }
      if (a[sortConfig.key] > b[sortConfig.key]) {
        return sortConfig.direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });

    return sortableItems;
  }, [contacts, searchTerm, sortConfig]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-16 h-16 border-4 border-t-transparent border-green-500 rounded-full"
        />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Contacts - Wabista Business Platform</title>
        <meta name="description" content="Manage your customer contacts efficiently." />
      </Helmet>
      <div className="space-y-6">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 flex items-center"><Users className="mr-3 text-green-600" />Contacts</h1>
              <p className="text-gray-500 mt-1">Manage your customer contact list.</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => setIsImportOpen(true)} className="glass-effect-button">
                <Upload className="w-4 h-4 mr-2" /> Import
              </Button>
              <Button onClick={() => openForm()} className="whatsapp-gradient">
                <Plus className="w-4 h-4 mr-2" /> Add Contact
              </Button>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="glass-effect rounded-2xl shadow-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search contacts..."
                className="pl-10 bg-white/50 border-gray-200/50"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr>
                  <th className="p-4 font-semibold text-gray-600 cursor-pointer" onClick={() => handleSort('name')}>
                    <div className="flex items-center">Name <ArrowUpDown className="w-3 h-3 ml-2" /></div>
                  </th>
                  <th className="p-4 font-semibold text-gray-600 cursor-pointer" onClick={() => handleSort('number')}>
                     <div className="flex items-center">Number <ArrowUpDown className="w-3 h-3 ml-2" /></div>
                  </th>
                  <th className="p-4 font-semibold text-gray-600">Tags</th>
                  <th className="p-4 font-semibold text-gray-600 cursor-pointer" onClick={() => handleSort('created_at')}>
                    <div className="flex items-center">Date Added <ArrowUpDown className="w-3 h-3 ml-2" /></div>
                  </th>
                  <th className="p-4 font-semibold text-gray-600 text-right">Actions</th>
                </tr>
              </thead>
              <AnimatePresence>
                <tbody>
                  {filteredAndSortedContacts.map(contact => (
                    <motion.tr
                      key={contact.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="border-t border-gray-200/50 hover:bg-gray-100/30 transition-colors"
                    >
                      <td className="p-4 flex items-center">
                        <Avatar className="mr-4">
                          <AvatarImage src={contact.avatar_url} />
                          <AvatarFallback className="bg-gradient-to-br from-green-400 to-blue-500 text-white font-bold">{getInitials(contact.name)}</AvatarFallback>
                        </Avatar>
                        <span className="font-medium text-gray-800">{contact.name}</span>
                      </td>
                      <td className="p-4 text-gray-600">{contact.number}</td>
                      <td className="p-4">
                        <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full">Lead</span>
                      </td>
                      <td className="p-4 text-gray-600">{new Date(contact.created_at).toLocaleDateString()}</td>
                      <td className="p-4 text-right">
                         <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon"><MoreHorizontal className="w-5 h-5" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openForm(contact)}><Edit className="w-4 h-4 mr-2" /> Edit</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setContactToDelete(contact)} className="text-red-600 focus:text-red-600"><Trash2 className="w-4 h-4 mr-2" /> Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </AnimatePresence>
            </table>
            {!loading && filteredAndSortedContacts.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                    <Users className="mx-auto h-12 w-12" />
                    <h3 className="mt-2 text-sm font-semibold">No contacts found</h3>
                    <p className="mt-1 text-sm">Get started by adding a new contact.</p>
                </div>
            )}
          </div>
        </motion.div>
      </div>
      
      {/* Add/Edit Contact Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[425px] glass-effect">
          <DialogHeader>
            <DialogTitle>{editingContact ? 'Edit Contact' : 'Add New Contact'}</DialogTitle>
            <DialogDescription>
              {editingContact ? 'Update the details for this contact.' : 'Fill in the details for the new contact.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleFormSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="name" className="text-right">Name</label>
                <Input id="name" name="name" value={formData.name} onChange={handleFormChange} className="col-span-3" required />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="number" className="text-right">Number</label>
                <Input id="number" name="number" value={formData.number} onChange={handleFormChange} className="col-span-3" required placeholder="+1234567890" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="avatar_url" className="text-right">Avatar URL</label>
                <Input id="avatar_url" name="avatar_url" value={formData.avatar_url} onChange={handleFormChange} className="col-span-3" placeholder="(Optional)" />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={closeForm}>Cancel</Button>
              <Button type="submit" className="whatsapp-gradient">{editingContact ? 'Save Changes' : 'Create Contact'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={!!contactToDelete} onOpenChange={() => setContactToDelete(null)}>
        <DialogContent className="sm:max-w-md glass-effect">
          <DialogHeader>
            <DialogTitle>Are you sure?</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete the contact <span className="font-bold">{contactToDelete?.name}</span> and all associated messages.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:justify-end">
            <Button type="button" variant="outline" onClick={() => setContactToDelete(null)}>Cancel</Button>
            <Button type="button" variant="destructive" onClick={handleDeleteContact}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Import Dialog Component */}
      <ImportContactsDialog 
        open={isImportOpen} 
        onOpenChange={setIsImportOpen}
        onImportSuccess={() => {
          fetchContacts();
          // Optional: Keep open or close automatically? Let the user close from results screen
        }} 
      />
    </>
  );
};

export default Contacts;
