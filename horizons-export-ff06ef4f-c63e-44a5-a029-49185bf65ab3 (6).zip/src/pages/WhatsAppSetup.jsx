import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, ArrowLeft, Loader2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { DialogClose } from '@/components/ui/dialog';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const FacebookIcon = () => (
  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
    <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.142v3.24h-1.918c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z" />
  </svg>
);

const setupSteps = [
    { title: "Continue with Facebook", description: "Login to your FB account." },
    { title: "Select your BM", description: "Choose your Business Manager." },
    { title: "Create or Select WABA", description: "Pick your WhatsApp account." },
    { title: "Verify your number", description: "Confirm your phone number." },
    { title: "Finish", description: "Complete the setup process." },
];

const WhatsAppSetup = ({ onComplete }) => {
  const [step, setStep] = useState('guide');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleStartFlow = () => {
    setStep('permissions');
  };

  const handlePermissions = () => {
    setIsLoading(true);
    setTimeout(() => {
      setStep('finish');
      setIsLoading(false);
    }, 2000);
  };

  const handleFinish = async () => {
    if (!user) return;
    const { error } = await supabase
      .from('profiles')
      .update({ is_whatsapp_connected: true })
      .eq('id', user.id);

    if (error) {
      toast({
        title: "Error",
        description: "Could not update connection status.",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Setup Complete! 🎉",
        description: "Your WhatsApp number is now connected.",
      });
    }
    if (onComplete) onComplete();
  };

  const renderContent = () => {
    switch (step) {
      case 'guide':
        return (
          <>
            <div className="p-8">
              <h2 className="text-xl font-bold text-gray-800 text-center">Connect Your WhatsApp Number</h2>
              <p className="text-sm text-gray-600 mt-2 text-center">Follow these steps to connect your WhatsApp Business API account.</p>
              
              <div className="mt-8 space-y-4">
                  {setupSteps.map((s, index) => (
                      <div key={s.title} className="flex items-center space-x-4">
                          <div className="flex-shrink-0 w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center font-bold text-gray-600">
                              {index + 1}
                          </div>
                          <div className="flex-1">
                            <p className="font-semibold text-gray-800">{s.title}</p>
                            <p className="text-sm text-gray-500">{s.description}</p>
                          </div>
                          {index < setupSteps.length - 1 && (
                            <ArrowRight className="w-5 h-5 text-gray-300" />
                          )}
                      </div>
                  ))}
              </div>
            </div>
            <div className="px-8 py-6 bg-gray-100 border-t">
              <Button onClick={handleStartFlow} className="w-full bg-[#1877F2] hover:bg-[#166fe5] text-white rounded-lg">
                <FacebookIcon />
                <span className="ml-2">Continue with Facebook</span>
              </Button>
            </div>
          </>
        );
      case 'permissions':
        return (
          <>
            <div className="p-8">
              <button onClick={() => setStep('guide')} className="text-sm text-gray-600 flex items-center mb-4 hover:text-gray-900"><ArrowLeft className="w-4 h-4 mr-1" /> Back</button>
              <h2 className="text-xl font-bold text-gray-800">What WhatsBiz will be able to do</h2>
              <p className="text-sm text-gray-600 mt-2">Allowing these permissions will not give WhatsBiz access to your personal Facebook account.</p>
              <ul className="space-y-3 mt-6 text-sm">
                <li className="flex items-start"><Check className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" /><span>Access your WhatsApp Business Account, phone numbers, and message templates.</span></li>
                <li className="flex items-start"><Check className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" /><span>Send messages on your behalf using the WhatsApp Business API.</span></li>
                <li className="flex items-start"><Check className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" /><span>Manage quality and get updates on your phone number's status.</span></li>
              </ul>
            </div>
            <div className="px-8 py-6 bg-gray-100 border-t">
              <Button onClick={handlePermissions} className="w-full whatsapp-gradient text-white rounded-lg" disabled={isLoading}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Allow & Continue"}
              </Button>
            </div>
          </>
        );
      case 'finish':
        return (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-800">You're All Set!</h2>
            <p className="text-sm text-gray-600 mt-2 mb-6">You have successfully linked WhatsBiz to your Meta account. Click finish to return to the dashboard.</p>
            <DialogClose asChild>
                <Button onClick={handleFinish} className="w-full whatsapp-gradient text-white rounded-lg">Finish</Button>
            </DialogClose>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-lg overflow-hidden">
      <div className="flex items-center justify-between p-4 border-b bg-gray-50">
        <div className="flex items-center space-x-2">
          <img src="https://upload.wikimedia.org/wikipedia/commons/6/6c/Facebook_Logo_2023.png" alt="Meta Logo" className="w-auto h-5" />
        </div>
        <p className="text-xs text-gray-500">Secure connection</p>
      </div>
      <div className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.2 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default WhatsAppSetup;