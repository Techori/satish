import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Plus, Mail, Phone, MoreVertical, Shield, UserCog, Users, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

const initialTeamMembers = [
  {
    id: 1,
    name: 'John Smith',
    email: 'john@example.com',
    phone: '+1 234 567 8900',
    role: 'Admin',
    status: 'Active',
    avatar: 'JS'
  },
  {
    id: 2,
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    phone: '+1 234 567 8901',
    role: 'Agent',
    status: 'Active',
    avatar: 'SJ'
  },
  {
    id: 3,
    name: 'Mike Wilson',
    email: 'mike@example.com',
    phone: '+1 234 567 8902',
    role: 'Agent',
    status: 'Away',
    avatar: 'MW'
  },
  {
    id: 4,
    name: 'Emily Brown',
    email: 'emily@example.com',
    phone: '+1 234 567 8903',
    role: 'Supervisor',
    status: 'Active',
    avatar: 'EB'
  },
];

const Team = () => {
  const { toast } = useToast();
  const [teamMembers, setTeamMembers] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', role: 'Agent' });

  const updateAndStoreMembers = useCallback((members) => {
    setTeamMembers(members);
    localStorage.setItem('whatsappTeamMembers', JSON.stringify(members));
  }, []);

  useEffect(() => {
    try {
      const storedMembers = localStorage.getItem('whatsappTeamMembers');
      if (storedMembers) {
        setTeamMembers(JSON.parse(storedMembers));
      } else {
        updateAndStoreMembers(initialTeamMembers);
      }
    } catch (error) {
      console.error("Failed to parse team members from localStorage", error);
      updateAndStoreMembers(initialTeamMembers);
    }
  }, [updateAndStoreMembers]);

  const stats = useMemo(() => {
    const activeNow = teamMembers.filter(m => m.status === 'Active').length;
    const admins = teamMembers.filter(m => m.role === 'Admin').length;
    const agents = teamMembers.filter(m => m.role === 'Agent').length;
    return {
      total: teamMembers.length,
      active: activeNow,
      admins,
      agents: agents + teamMembers.filter(m => m.role === 'Supervisor').length
    };
  }, [teamMembers]);

  const handleOpenModal = (member = null) => {
    setEditingMember(member);
    if (member) {
      setFormData({ name: member.name, email: member.email, phone: member.phone, role: member.role });
    } else {
      setFormData({ name: '', email: '', phone: '', role: 'Agent' });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingMember(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleRoleChange = (value) => {
    setFormData(prev => ({ ...prev, role: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: "Name and Email are required.",
      });
      return;
    }

    let updatedMembers;
    if (editingMember) {
      updatedMembers = teamMembers.map(m => m.id === editingMember.id ? { ...m, ...formData } : m);
      toast({ title: "Member Updated", description: `${formData.name} has been successfully updated.` });
    } else {
      const newMember = {
        id: Date.now(),
        ...formData,
        status: 'Active',
        avatar: formData.name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2),
      };
      updatedMembers = [...teamMembers, newMember];
      toast({ title: "Member Invited", description: `${formData.name} has been successfully invited.` });
    }

    updateAndStoreMembers(updatedMembers);
    handleCloseModal();
  };

  const handleDeleteMember = (memberId) => {
    const updatedMembers = teamMembers.filter(m => m.id !== memberId);
    updateAndStoreMembers(updatedMembers);
    toast({ title: "Member Removed", description: "The team member has been successfully removed." });
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'Admin': return 'bg-purple-100 text-purple-700';
      case 'Supervisor': return 'bg-blue-100 text-blue-700';
      case 'Agent': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active': return 'bg-green-500';
      case 'Away': return 'bg-orange-500';
      case 'Offline': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  return (
    <>
      <Helmet>
        <title>Team - WhatsApp Business Platform</title>
        <meta name="description" content="Manage your team members, roles, and permissions for WhatsApp Business collaboration." />
      </Helmet>

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Team Management</h1>
            <p className="text-gray-600 mt-1">Manage team members and their permissions</p>
          </div>
          <Button onClick={() => handleOpenModal()} className="whatsapp-gradient text-white rounded-xl shadow-lg">
            <Plus className="w-4 h-4 mr-2" />
            Invite Member
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: 'Total Members', value: stats.total, icon: Users, color: 'from-blue-500 to-blue-600' },
            { label: 'Active Now', value: stats.active, icon: UserCog, color: 'from-green-500 to-green-600' },
            { label: 'Admins', value: stats.admins, icon: Shield, color: 'from-purple-500 to-purple-600' },
            { label: 'Agents & Supervisors', value: stats.agents, icon: Users, color: 'from-orange-500 to-orange-600' },
          ].map((stat, index) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="glass-effect rounded-2xl p-6 shadow-lg">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">{stat.label}</p>
                  <p className="text-3xl font-bold mt-1 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}><stat.icon className="w-6 h-6 text-white" /></div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {teamMembers.map((member, index) => (
            <motion.div key={member.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="glass-effect rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">{member.avatar}</div>
                    <div className={`absolute bottom-0 right-0 w-4 h-4 ${getStatusColor(member.status)} border-2 border-white rounded-full`}></div>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{member.name}</h3>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium mt-1 ${getRoleColor(member.role)}`}>{member.role}</span>
                  </div>
                </div>
                 <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon"><MoreVertical className="w-5 h-5" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenModal(member)}><Edit className="mr-2 h-4 w-4" /> Edit</DropdownMenuItem>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <DropdownMenuItem onSelect={(e) => e.preventDefault()} className="text-red-600 focus:text-red-600"><Trash2 className="mr-2 h-4 w-4" /> Delete</DropdownMenuItem>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader><AlertDialogTitle>Are you sure?</AlertDialogTitle><AlertDialogDescription>This action cannot be undone. This will permanently remove {member.name} from the team.</AlertDialogDescription></AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDeleteMember(member.id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <div className="space-y-3">
                <div className="flex items-center space-x-2 text-sm text-gray-600"><Mail className="w-4 h-4" /><span>{member.email}</span></div>
                <div className="flex items-center space-x-2 text-sm text-gray-600"><Phone className="w-4 h-4" /><span>{member.phone}</span></div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-effect rounded-2xl p-8 shadow-lg">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Roles & Permissions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { role: 'Admin', color: 'from-purple-500 to-purple-600', permissions: ['Full access', 'Manage team', 'View analytics', 'Configure settings'] },
              { role: 'Supervisor', color: 'from-blue-500 to-blue-600', permissions: ['View analytics', 'Manage agents', 'Access inbox', 'Create broadcasts'] },
              { role: 'Agent', color: 'from-green-500 to-green-600', permissions: ['Access inbox', 'Reply to messages', 'View contacts', 'Use templates'] },
            ].map((roleInfo) => (
              <div key={roleInfo.role} className="bg-white/50 rounded-xl p-6">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${roleInfo.color} flex items-center justify-center mb-4 shadow-lg`}><Shield className="w-6 h-6 text-white" /></div>
                <h4 className="text-lg font-bold text-gray-900 mb-3">{roleInfo.role}</h4>
                <ul className="space-y-2">{roleInfo.permissions.map((p, i) => <li key={i} className="text-sm text-gray-600 flex items-center space-x-2"><div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div><span>{p}</span></li>)}</ul>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingMember ? 'Edit Team Member' : 'Invite New Member'}</DialogTitle>
            <DialogDescription>{editingMember ? `Update the details for ${editingMember.name}.` : 'Fill in the details to invite a new member to your team.'}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">Name</Label>
              <Input id="name" name="name" value={formData.name} onChange={handleInputChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">Email</Label>
              <Input id="email" name="email" type="email" value={formData.email} onChange={handleInputChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="phone" className="text-right">Phone</Label>
              <Input id="phone" name="phone" value={formData.phone} onChange={handleInputChange} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="role" className="text-right">Role</Label>
              <Select name="role" value={formData.role} onValueChange={handleRoleChange}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select a role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Agent">Agent</SelectItem>
                  <SelectItem value="Supervisor">Supervisor</SelectItem>
                  <SelectItem value="Admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="submit" className="whatsapp-gradient">{editingMember ? 'Save Changes' : 'Invite Member'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Team;