import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageSquare, 
  Users, 
  TrendingUp, 
  Clock,
  ArrowUp,
  ArrowDown,
  Zap,
  CheckCircle,
  BarChart,
  Send,
  Briefcase,
  UserPlus,
  Bot,
  ArrowRight,
  ChevronRight
} from 'lucide-react';
import { LineChart, Line, BarChart as ReBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Button } from '@/components/ui/button';
import WhatsAppSetup from '@/pages/WhatsAppSetup';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const FacebookIcon = () => (
  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
    <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.142v3.24h-1.918c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z" />
  </svg>
);

const setupSteps = [
    { title: "Continue with Facebook", description: "Login to your FB account." },
    { title: "Select your BM", description: "Choose your Business Manager." },
    { title: "Create or Select WABA", description: "Pick your WhatsApp account." },
    { title: "Verify your number", description: "Confirm your phone number." },
    { title: "Finish", description: "Complete the setup process." },
];

const Dashboard = () => {
  const [isNumberConnected, setIsNumberConnected] = useState(false);
  const [showSetupGuide, setShowSetupGuide] = useState(false);
  const [isSetupModalOpen, setIsSetupModalOpen] = useState(false);
  const [dashboardStats, setDashboardStats] = useState({
    totalMessages: { value: 0, change: '+0.0%' },
    activeContacts: { value: 0, change: '+0.0%' },
    responseRate: { value: '0.0%', change: '+0.0%' },
    avgResponseTime: { value: '0.0 min', change: '+0.0%' },
  });
  const [messageData, setMessageData] = useState([]);
  const [conversationData, setConversationData] = useState([]);
  const [recentActivity, setRecentActivity] = useState([]);
  const { user } = useAuth();

  const handleSetupComplete = async () => {
    if (!user) return;
    const { error } = await supabase
      .from('profiles')
      .update({ is_whatsapp_connected: true })
      .eq('id', user.id);
    
    if (!error) {
      setIsNumberConnected(true);
    }
    setIsSetupModalOpen(false);
    setShowSetupGuide(false);
  };

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!user) return;

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('is_whatsapp_connected')
        .eq('id', user.id)
        .single();

      if (profileError) {
        console.error('Error fetching profile:', profileError);
      } else {
        setIsNumberConnected(profile?.is_whatsapp_connected || false);
      }
  
      const { data: messages, error: messagesError } = await supabase
        .from('messages')
        .select(`
          content, 
          created_at, 
          is_from_user,
          is_welcome_message,
          contact_id,
          contacts ( name )
        `)
        .eq('user_id', user.id);

      if (messagesError) {
        console.error('Error fetching messages:', messagesError);
        return;
      }
      
      const { data: contacts, error: contactsError } = await supabase
        .from('contacts')
        .select('id, name, created_at')
        .eq('user_id', user.id);

      if(contactsError) {
        console.error('Error fetching contacts:', contactsError);
        return;
      }

      const allMessagesFlat = messages.map(m => ({ ...m, timestamp: new Date(m.created_at) }));
      const allContacts = contacts.map(c => ({...c, timestamp: new Date(c.created_at) }));
  
      const now = new Date();
      const t24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const t48h = new Date(now.getTime() - 48 * 60 * 60 * 1000);
  
      const welcomeCurrent = allMessagesFlat.filter(m => m.is_welcome_message && m.timestamp > t24h).length;
      const welcomePrevious = allMessagesFlat.filter(m => m.is_welcome_message && m.timestamp > t48h && m.timestamp <= t24h).length;
      const welcomeChange = welcomePrevious > 0 ? ((welcomeCurrent - welcomePrevious) / welcomePrevious * 100).toFixed(1) : (welcomeCurrent > 0 ? 100.0 : 0.0);
  
      const activeCurrentIds = new Set(allMessagesFlat.filter(m => !m.is_from_user && m.timestamp > t24h).map(m => m.contact_id));
      const activePreviousIds = new Set(allMessagesFlat.filter(m => !m.is_from_user && m.timestamp > t48h && m.timestamp <= t24h).map(m => m.contact_id));
      const activeCurrent = activeCurrentIds.size;
      const activePrevious = activePreviousIds.size;
      const activeChange = activePrevious > 0 ? ((activeCurrent - activePrevious) / activePrevious * 100).toFixed(1) : (activeCurrent > 0 ? 100.0 : 0.0);
  
      setDashboardStats(prev => ({
        ...prev,
        totalMessages: { value: welcomeCurrent, change: `${welcomeChange >= 0 ? '+' : ''}${welcomeChange}%` },
        activeContacts: { value: activeCurrent, change: `${activeChange >= 0 ? '+' : ''}${activeChange}%` },
        responseRate: { value: 'N/A', change: '0.0%' },
        avgResponseTime: { value: 'N/A', change: '0.0%' },
      }));
  
      const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const weeklyMessages = weekDays.map((day) => ({ name: day, messages: 0 }));
      const last7Days = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      allMessagesFlat.filter(m => m.timestamp > last7Days).forEach(m => {
        weeklyMessages[m.timestamp.getDay()].messages++;
      });
      setMessageData(weeklyMessages);
  
      const monthlyMessageVolume = [{ name: 'Week 4', messages: 0 }, { name: 'Week 3', messages: 0 }, { name: 'Week 2', messages: 0 }, { name: 'Week 1', messages: 0 }];
      allMessagesFlat.forEach(m => {
        const daysAgo = (now - m.timestamp) / (1000 * 3600 * 24);
        if (daysAgo < 7) monthlyMessageVolume[0].messages++;
        else if (daysAgo < 14) monthlyMessageVolume[1].messages++;
        else if (daysAgo < 21) monthlyMessageVolume[2].messages++;
        else if (daysAgo < 28) monthlyMessageVolume[3].messages++;
      });
      setConversationData(monthlyMessageVolume.reverse());
  
      const recentMsgs = allMessagesFlat
        .filter(m => !m.is_from_user)
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 2)
        .map(m => ({
          action: `New message from ${m.contacts?.name || 'Unknown User'}`,
          time: m.timestamp,
          type: 'message'
        }));
  
      const recentContactsAdded = allContacts
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 1)
        .map(c => ({ action: `New contact added: ${c.name}`, time: c.timestamp, type: 'contact' }));
  
      const activity = [...recentMsgs, ...recentContactsAdded]
        .sort((a, b) => b.time - a.time)
        .slice(0, 4);
      setRecentActivity(activity);
    };

    fetchDashboardData();

  }, [user]);

  const formatTimeAgo = (date) => {
    const seconds = Math.floor((new Date() - date) / 1000);
    if (seconds < 5) return "just now";
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " years ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " months ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " days ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " hours ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " minutes ago";
    return Math.floor(seconds) + " seconds ago";
  };

  const stats = [
    { name: 'Total Welcome Messages', data: dashboardStats.totalMessages, icon: MessageSquare, color: 'from-blue-500 to-blue-600' },
    { name: 'Active Contacts (24h)', data: dashboardStats.activeContacts, icon: Users, color: 'from-green-500 to-green-600' },
    { name: 'Response Rate', data: dashboardStats.responseRate, icon: TrendingUp, color: 'from-purple-500 to-purple-600' },
    { name: 'Avg Response Time', data: dashboardStats.avgResponseTime, icon: Clock, color: 'from-orange-500 to-orange-600' },
  ];

  const ConnectionStatus = () => (
    <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="glass-effect rounded-2xl p-6 shadow-lg mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-gray-900 flex items-center"><CheckCircle className="w-6 h-6 text-green-600 mr-3" /> WhatsApp API Connected</h3>
        <span className="text-sm font-medium text-green-600 bg-green-100 px-3 py-1 rounded-full">Active</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white/50 rounded-xl p-4"><div className="flex items-center text-sm text-gray-600 mb-2"><Briefcase className="w-4 h-4 mr-2" /><span>Business Name</span></div><p className="text-lg font-semibold text-gray-900">WhatsBiz Inc.</p></div>
        <div className="bg-white/50 rounded-xl p-4"><div className="flex items-center text-sm text-gray-600 mb-2"><MessageSquare className="w-4 h-4 mr-2" /><span>Connected Number</span></div><p className="text-lg font-semibold text-gray-900">+1 234 567 8900</p></div>
        <div className="bg-white/50 rounded-xl p-4"><div className="flex items-center text-sm text-gray-600 mb-2"><BarChart className="w-4 h-4 mr-2" /><span>Message Quality</span></div><p className="text-lg font-semibold text-green-600">High</p></div>
        <div className="bg-white/50 rounded-xl p-4"><div className="flex items-center text-sm text-gray-600 mb-2"><Send className="w-4 h-4 mr-2" /><span>Broadcast Limit</span></div><p className="text-lg font-semibold text-gray-900">10,000 / 24h</p></div>
      </div>
    </motion.div>
  );

  const ConnectNumberPrompt = () => (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="whatsapp-gradient rounded-2xl p-8 shadow-lg mb-8">
      <div className="flex flex-col items-center text-center">
        <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4 shadow-lg">
          <Zap className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-2xl font-bold text-white mb-2">Connect Your WhatsApp Number</h3>
        <p className="text-white/80 mb-6 max-w-md">Integrate your WhatsApp Business API to unlock all features, including broadcasting and automated chatbots.</p>
        <Button onClick={() => setShowSetupGuide(true)} size="lg" className="bg-white text-green-700 hover:bg-gray-100 rounded-xl px-8 py-3 font-bold text-base transition-all shadow-lg hover:shadow-xl">
          Connect Number
          <ChevronRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </motion.div>
  );

  const SetupGuide = () => (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="bg-white rounded-2xl p-8 shadow-lg mb-8 border border-gray-200/80">
      <h3 className="text-2xl font-bold text-gray-800 mb-2 text-center">Connection Guide</h3>
      <p className="text-gray-600 mb-8 text-center">Follow these steps to connect your WhatsApp Business API account.</p>
      
      <div className="max-w-md mx-auto space-y-6">
        {setupSteps.map((step, index) => (
          <div key={step.title} className="flex items-center space-x-4">
            <div className="flex-shrink-0 w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center font-bold text-green-700 border-2 border-gray-200">
              {index + 1}
            </div>
            <div className="flex-1">
              <p className="font-semibold text-gray-800">{step.title}</p>
              <p className="text-sm text-gray-500">{step.description}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10 flex justify-center">
        <Button onClick={() => setIsSetupModalOpen(true)} size="lg" className="bg-[#1877F2] hover:bg-[#166fe5] text-white rounded-xl px-8 py-3 font-bold text-base transition-all shadow-lg">
          <FacebookIcon />
          <span className="ml-2">Continue with Facebook</span>
        </Button>
      </div>
    </motion.div>
  );

  const ActivityIcon = ({ type }) => {
    const icons = {
      message: <MessageSquare className="w-5 h-5 text-blue-500" />,
      contact: <UserPlus className="w-5 h-5 text-green-500" />,
      broadcast: <Send className="w-5 h-5 text-purple-500" />,
      bot: <Bot className="w-5 h-5 text-orange-500" />,
    };
    return <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">{icons[type] || <Zap className="w-5 h-5 text-gray-500"/>}</div>;
  };

  return (
    <>
      <Helmet>
        <title>Dashboard - WhatsApp Business Platform</title>
        <meta name="description" content="Monitor your WhatsApp Business performance with real-time analytics and insights." />
      </Helmet>
      <div className="space-y-8">
        <AnimatePresence mode="wait">
          {isNumberConnected ? (
            <ConnectionStatus key="status" />
          ) : showSetupGuide ? (
            <SetupGuide key="guide" />
          ) : (
            <ConnectNumberPrompt key="prompt" />
          )}
        </AnimatePresence>
        
        <Dialog open={isSetupModalOpen} onOpenChange={setIsSetupModalOpen}>
          <DialogContent className="p-0 border-0 max-w-2xl bg-gray-50">
            <WhatsAppSetup onComplete={handleSetupComplete} />
          </DialogContent>
        </Dialog>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => {
            const isGrowthPositive = parseFloat(stat.data.change) > 0;
            const isGrowthNegative = parseFloat(stat.data.change) < 0;
            const isChangeNeutral = parseFloat(stat.data.change) === 0;

            const isAvgTime = stat.name.includes('Time');
            let isGoodChange = isGrowthPositive;
            if (isAvgTime) isGoodChange = isGrowthNegative;

            return (
              <motion.div key={stat.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="glass-effect rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-sm text-gray-600 font-medium">{stat.name}</p>
                    <p className="text-3xl font-bold mt-2 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">{stat.data.value}</p>
                    <div className="flex items-center mt-2 space-x-1">
                      {!isChangeNeutral && (
                        isGoodChange ? <ArrowUp className="w-4 h-4 text-green-600" /> : <ArrowDown className="w-4 h-4 text-red-600" />
                      )}
                      <span className={isChangeNeutral ? 'text-gray-500' : (isGoodChange ? 'text-green-600' : 'text-red-600')}>{stat.data.change}</span>
                    </div>
                  </div>
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}><stat.icon className="w-6 h-6 text-white" /></div>
                </div>
              </motion.div>
            )
          })}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }} className="glass-effect rounded-2xl p-6 shadow-lg">
            <h3 className="text-lg font-bold mb-4">Messages This Week</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={messageData}><CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" /><XAxis dataKey="name" stroke="#6b7280" /><YAxis stroke="#6b7280" /><Tooltip contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: 'none', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)' }}/><Line type="monotone" dataKey="messages" stroke="#25D366" strokeWidth={3} dot={{ fill: '#25D366', r: 5 }}/></LineChart>
            </ResponsiveContainer>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }} className="glass-effect rounded-2xl p-6 shadow-lg">
            <h3 className="text-lg font-bold mb-4">Message Volume This Month</h3>
            <ResponsiveContainer width="100%" height={300}>
              <ReBarChart data={conversationData}><CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" /><XAxis dataKey="name" stroke="#6b7280" /><YAxis stroke="#6b7280" /><Tooltip contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: 'none', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)' }}/><Bar dataKey="messages" fill="url(#colorGradient)" radius={[8, 8, 0, 0]}/><defs><linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#25D366" /><stop offset="100%" stopColor="#128C7E" /></linearGradient></defs></ReBarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="glass-effect rounded-2xl p-6 shadow-lg">
          <h3 className="text-lg font-bold mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivity.length > 0 ? recentActivity.map((activity, index) => (
              <div key={index} className="flex items-center space-x-4 p-3 bg-white/50 rounded-xl hover:bg-white/70 transition-colors">
                <ActivityIcon type={activity.type} />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{activity.action}</p>
                  <p className="text-sm text-gray-600">{formatTimeAgo(new Date(activity.time))}</p>
                </div>
              </div>
            )) : <p className="text-center text-gray-500 py-4">No recent activity to show.</p>}
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Dashboard;