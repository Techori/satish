import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Search, Filter, Copy, Edit, Trash2, CheckCircle, Clock, XCircle, Phone, Globe, MessageSquare, Image, Video, FileText, X, Sparkles, FilePlus2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuCheckboxItem, DropdownMenuLabel, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const recommendedTemplates = [
    { name: 'seasonal_sale', category: 'MARKETING', body: 'Our {{1}} sale is here! Get up to {{2}}% off on selected items. Don\'t miss out!', footer: 'Sale ends soon!', buttons: [{type: 'URL', text: 'Shop Now', url: 'https://example.com/sale'}], header: {type: 'IMAGE'} },
    { name: 'abandoned_cart', category: 'MARKETING', body: 'Hi {{1}}, you left something in your cart! Complete your purchase now and get free shipping.', buttons: [{type: 'URL', text: 'View Cart', url: 'https://example.com/cart'}]},
    { name: 'appointment_confirmation', category: 'UTILITY', body: 'Your appointment with {{1}} on {{2}} is confirmed. We look forward to seeing you!', buttons: [{type: 'PHONE_NUMBER', text: 'Call Us', phoneNumber: '+15550123456'}]},
    { name: 'feedback_request', category: 'UTILITY', body: 'Hi {{1}}, thank you for your recent purchase. Would you mind sharing your feedback? It helps us improve!', buttons: [{type: 'QUICK_REPLY', text: 'Sure!'}, {type: 'QUICK_REPLY', text: 'Later'}]},
];

const TemplatePreview = ({ header, body, footer, buttons }) => {
    const renderHeader = () => {
        if (!header || header.type === 'NONE') return null;
        
        const headerStyles = "p-3 bg-gray-300 flex items-center justify-center text-gray-500";
        switch (header.type) {
            case 'TEXT':
                return <div className="p-3 bg-white font-bold break-words">{header.text.replace(/\{\{(\d+)\}\}/g, '[variable]')}</div>;
            case 'IMAGE':
                return <div className={headerStyles}><Image className="w-8 h-8" /></div>;
            case 'VIDEO':
                return <div className={headerStyles}><Video className="w-8 h-8" /></div>;
            case 'DOCUMENT':
                return <div className={headerStyles}><FileText className="w-8 h-8" /></div>;
            default:
                return null;
        }
    };

    return (
        <div className="bg-gray-200 p-4 rounded-2xl w-full max-w-sm mx-auto">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
                 <div className="p-2 bg-green-500 text-white text-xs text-center">
                    <span>Your Business Name</span>
                </div>
                {renderHeader()}
                <div className="p-3 bg-gray-100">
                    <div className="bg-white p-3 rounded-lg shadow-sm text-sm text-gray-800 break-words">
                        <p>{body ? body.replace(/\{\{(\d+)\}\}/g, '[variable]') : 'Your message content will appear here...'}</p>
                        {footer && <p className="text-xs text-gray-500 mt-2">{footer.replace(/\{\{(\d+)\}\}/g, '[variable]')}</p>}
                    </div>
                </div>
                {buttons && buttons.length > 0 && (
                    <div className="flex flex-col border-t border-gray-200">
                        {buttons.map((btn, i) => (
                            <div key={i} className="text-center p-2 text-blue-500 bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer border-t border-gray-200 first:border-t-0 flex items-center justify-center gap-2">
                               {btn.type === 'URL' && <Globe className="w-4 h-4" />}
                               {btn.type === 'PHONE_NUMBER' && <Phone className="w-4 h-4" />}
                               <span>{btn.text || 'Button'}</span>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};


const Templates = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [templates, setTemplates] = useState([]);
  const [activeFilters, setActiveFilters] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [isChoiceModalOpen, setIsChoiceModalOpen] = useState(false);
  const [isRecommendedModalOpen, setIsRecommendedModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  
  const initialFormData = {
      name: '', 
      category: 'UTILITY', 
      language: 'en_US', 
      header: { type: 'NONE', text: '' },
      body: '',
      footer: '',
      buttons: []
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchTemplates = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('templates')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching templates:', error);
      toast({ title: 'Error', description: 'Could not fetch templates.', variant: 'destructive' });
    } else {
      setTemplates(data);
    }
    setLoading(false);
  }, [user, toast]);

  useEffect(() => {
    fetchTemplates();
  }, [fetchTemplates]);
  
  const handleFilterChange = (status) => setActiveFilters(prev => prev.includes(status) ? prev.filter(s => s !== status) : [...prev, status]);
  const handleCopy = (content) => { navigator.clipboard.writeText(JSON.stringify(content, null, 2)); toast({ title: 'Copied!', description: 'Template JSON copied.' }); };

  const openAddDialog = () => { setEditingTemplate(null); setFormData(initialFormData); setIsModalOpen(true); };
  const openEditDialog = (template) => { 
      setEditingTemplate(template); 
      setFormData({
          name: template.name,
          category: template.category,
          language: template.language,
          header: template.header || { type: 'NONE', text: '' },
          body: template.body || '',
          footer: template.footer || '',
          buttons: template.buttons || []
      });
      setIsModalOpen(true);
  };
  
  const handleSaveTemplate = async () => {
    if (!user) return;
    if (!formData.name || !formData.body) { toast({ title: "Validation Error", description: "Template Name and Body are required.", variant: "destructive" }); return; }
    for(const btn of formData.buttons) {
      if(!btn.text) { toast({ title: "Validation Error", description: "All buttons must have text.", variant: "destructive" }); return; }
      if(btn.type === 'URL' && !btn.url) { toast({ title: "Validation Error", description: "URL Call to Action must have a URL.", variant: "destructive" }); return; }
      if(btn.type === 'PHONE_NUMBER' && !btn.phoneNumber) { toast({ title: "Validation Error", description: "Phone Call to Action must have a number.", variant: "destructive" }); return; }
    }
    
    const formattedName = formData.name.toLowerCase().replace(/\s+/g, '_');
    const finalData = { ...formData, name: formattedName, user_id: user.id, status: 'Pending' };

    if (editingTemplate) {
      const { error } = await supabase
        .from('templates')
        .update({ ...finalData, updated_at: new Date().toISOString() })
        .eq('id', editingTemplate.id);
      if (error) {
        toast({ title: "Error updating template", description: error.message, variant: "destructive" });
      } else {
        toast({ title: "Template Updated!", description: `${finalData.name} is now pending approval.` });
      }
    } else {
      const { error } = await supabase
        .from('templates')
        .insert(finalData);
      if (error) {
        toast({ title: "Error creating template", description: error.message, variant: "destructive" });
      } else {
        toast({ title: "Template Created!", description: `${finalData.name} has been submitted for approval.` });
      }
    }
    await fetchTemplates();
    setIsModalOpen(false);
  };

  const handleDeleteTemplate = async (templateId) => {
    const { error } = await supabase.from('templates').delete().eq('id', templateId);
    if (error) {
      toast({ title: "Error deleting template", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Template Deleted", variant: "destructive" });
      setTemplates(templates.filter(t => t.id !== templateId));
    }
  };

  const handleInputChange = (e) => { const { name, value } = e.target; setFormData(p => ({ ...p, [name]: value })); };
  const handleHeaderChange = (e) => { const { name, value } = e.target; setFormData(p => ({ ...p, header: {...p.header, [name]: value} })); };
  const handleButtonChange = (index, e) => {
      const { name, value } = e.target;
      const newButtons = [...formData.buttons];
      newButtons[index][name] = value;
      setFormData(p => ({ ...p, buttons: newButtons }));
  };
  
  const addButton = (type) => {
      if (formData.buttons.length >= 3) {
          toast({ title: "Button Limit Reached", description: "You can add a maximum of 3 buttons.", variant: "destructive"});
          return;
      }
      let newButton;
      if (type === 'QUICK_REPLY') newButton = {type: 'QUICK_REPLY', text: ''};
      else if (type === 'URL') newButton = {type: 'URL', text: '', url: ''};
      else newButton = {type: 'PHONE_NUMBER', text: '', phoneNumber: ''};

      setFormData(p => ({ ...p, buttons: [...p.buttons, newButton]}));
  };
  const removeButton = (index) => setFormData(p => ({ ...p, buttons: p.buttons.filter((_, i) => i !== index)}));
  
  const handleCreateFromScratch = () => {
    setIsChoiceModalOpen(false);
    openAddDialog();
  };

  const handleUseRecommended = () => {
    setIsChoiceModalOpen(false);
    setIsRecommendedModalOpen(true);
  };

  const handleSelectRecommended = (template) => {
    setIsRecommendedModalOpen(false);
    setEditingTemplate(null);
    setFormData({
        ...initialFormData,
        ...template,
        language: 'en_US', // default language
    });
    setIsModalOpen(true);
  };

  const getStatusIcon = (status) => ({ Approved: <CheckCircle className="w-4 h-4 text-green-600" />, Pending: <Clock className="w-4 h-4 text-orange-600" />, Rejected: <XCircle className="w-4 h-4 text-red-600" /> }[status]);
  const getStatusColor = (status) => ({ Approved: 'bg-green-100 text-green-700', Pending: 'bg-orange-100 text-orange-700', Rejected: 'bg-red-100 text-red-700' }[status] || 'bg-gray-100 text-gray-700');
  
  const filteredTemplates = templates.filter(t => (t.name.toLowerCase().includes(searchTerm.toLowerCase()) || t.category.toLowerCase().includes(searchTerm.toLowerCase())) && (activeFilters.length === 0 || activeFilters.includes(t.status)));
  const stats = useMemo(() => ({ total: templates.length, approved: templates.filter(t => t.status === 'Approved').length, pending: templates.filter(t => t.status === 'Pending').length, rejected: templates.filter(t => t.status === 'Rejected').length }), [templates]);

  return ( <>
      <Helmet><title>Templates - WhatsApp Business Platform</title><meta name="description" content="Create and manage WhatsApp message templates." /></Helmet>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div><h1 className="text-3xl font-bold text-gray-900">Message Templates</h1><p className="text-gray-600 mt-1">Create pre-approved templates for business messaging</p></div>
          <Button onClick={() => setIsChoiceModalOpen(true)} className="whatsapp-gradient text-white rounded-xl"><Plus className="w-4 h-4 mr-2" />Create Template</Button>
        </div>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" /><input type="text" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Search templates..." className="w-full pl-10 pr-4 py-3 bg-white rounded-xl border focus:ring-2 focus:ring-green-500 shadow-sm" /></div>
          <DropdownMenu><DropdownMenuTrigger asChild><Button variant="outline" className="rounded-xl"><Filter className="w-4 h-4 mr-2" />Filter{activeFilters.length > 0 && <span className="ml-2 bg-green-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">{activeFilters.length}</span>}</Button></DropdownMenuTrigger><DropdownMenuContent><DropdownMenuLabel>Filter by Status</DropdownMenuLabel><DropdownMenuSeparator />{['Approved', 'Pending', 'Rejected'].map(status => (<DropdownMenuCheckboxItem key={status} checked={activeFilters.includes(status)} onSelect={(e) => e.preventDefault()} onCheckedChange={() => handleFilterChange(status)}>{status}</DropdownMenuCheckboxItem>))}</DropdownMenuContent></DropdownMenu>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">{[{ label: 'Total Templates', value: stats.total, color: 'from-blue-500 to-blue-600' }, { label: 'Approved', value: stats.approved, color: 'from-green-500 to-green-600' }, { label: 'Pending', value: stats.pending, color: 'from-orange-500 to-orange-600' }, { label: 'Rejected', value: stats.rejected, color: 'from-red-500 to-red-600' }].map((stat, i) => (<motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="glass-effect rounded-xl p-4 shadow-lg"><p className="text-sm text-gray-600 font-medium">{stat.label}</p><p className={`text-2xl font-bold mt-1 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>{stat.value}</p></motion.div>))}</div>
        
        {loading ? (
          <div className="flex justify-center items-center h-64"><Loader2 className="w-12 h-12 text-green-500 animate-spin" /></div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6"><AnimatePresence>{filteredTemplates.map((t, i) => (<motion.div key={t.id} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ delay: i * 0.05 }} className="glass-effect rounded-2xl p-6 shadow-lg"><div className="flex items-start justify-between mb-4"><div className="flex-1"><h3 className="text-lg font-bold text-gray-900 mb-2">{t.name}</h3><div className="flex flex-wrap items-center gap-2"><span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">{t.category}</span><span className={`px-2 py-1 text-xs font-medium rounded-full flex items-center space-x-1 ${getStatusColor(t.status)}`}>{getStatusIcon(t.status)}<span>{t.status}</span></span><span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full">{t.language}</span></div></div></div><div className="bg-white/50 rounded-xl p-4 mb-4 space-y-2 font-mono text-sm"><p className="text-gray-500 text-xs uppercase">Header</p>{t.header?.type === 'TEXT' ? <p>{t.header.text}</p> : (t.header?.type !== 'NONE' && t.header?.type ? <p className='flex items-center gap-2'>{t.header.type} <span className="text-gray-400"> (Media)</span></p> : <p className="text-gray-400">None</p>)}<p className="text-gray-500 text-xs uppercase pt-2">Body</p><p>{t.body}</p>{t.footer && <><p className="text-gray-500 text-xs uppercase pt-2">Footer</p><p>{t.footer}</p></>}{t.buttons?.length > 0 && <><p className="text-gray-500 text-xs uppercase pt-2">Buttons</p><div className="flex flex-col gap-1">{t.buttons.map((b,i)=><span key={i} className="text-blue-600">[{b.type}] {b.text}</span>)}</div></>}</div><div className="flex items-center gap-2"><Button onClick={() => handleCopy(t)} variant="outline" size="sm" className="flex-1 rounded-xl"><Copy className="w-4 h-4 mr-2" />Copy JSON</Button><Button onClick={() => openEditDialog(t)} variant="outline" size="sm" className="flex-1 rounded-xl"><Edit className="w-4 h-4 mr-2" />Edit</Button><AlertDialog><AlertDialogTrigger asChild><Button variant="outline" size="sm" className="rounded-xl text-red-600 hover:bg-red-50 hover:text-red-700"><Trash2 className="w-4 h-4" /></Button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle><AlertDialogDescription>This action cannot be undone. This will permanently delete the template.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => handleDeleteTemplate(t.id)}>Delete</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog></div></motion.div>))}</AnimatePresence></div>
        )}
        
        <Dialog open={isChoiceModalOpen} onOpenChange={setIsChoiceModalOpen}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle className="text-2xl font-bold text-center">How do you want to start?</DialogTitle>
                    <DialogDescription className="text-center">Choose a recommended template to get started quickly, or build one from scratch.</DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6">
                    <button onClick={handleUseRecommended} className="flex flex-col items-center justify-center p-6 border-2 border-transparent rounded-2xl bg-green-50 hover:border-green-500 transition-all duration-300 group">
                        <div className="p-4 rounded-full bg-green-100 group-hover:bg-green-500 transition-colors">
                            <Sparkles className="w-8 h-8 text-green-600 group-hover:text-white transition-colors" />
                        </div>
                        <h3 className="font-bold text-lg mt-4">Use Recommended</h3>
                        <p className="text-sm text-gray-500 mt-1 text-center">Start with a pre-built, popular template.</p>
                    </button>
                    <button onClick={handleCreateFromScratch} className="flex flex-col items-center justify-center p-6 border rounded-2xl hover:border-gray-400 transition-all duration-300 group">
                        <div className="p-4 rounded-full bg-gray-100 group-hover:bg-gray-200 transition-colors">
                            <FilePlus2 className="w-8 h-8 text-gray-600" />
                        </div>
                        <h3 className="font-bold text-lg mt-4">Create From Scratch</h3>
                        <p className="text-sm text-gray-500 mt-1 text-center">Design a custom template for your needs.</p>
                    </button>
                </div>
            </DialogContent>
        </Dialog>

        <Dialog open={isRecommendedModalOpen} onOpenChange={setIsRecommendedModalOpen}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="text-2xl font-bold">Choose a Recommended Template</DialogTitle>
                    <DialogDescription>Select a template to get started. You can customize it in the next step.</DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                    {recommendedTemplates.map((template, index) => (
                        <div key={index} className="border rounded-lg p-4 flex flex-col justify-between hover:shadow-lg hover:border-green-500 transition-all cursor-pointer" onClick={() => handleSelectRecommended(template)}>
                            <div>
                                <h3 className="font-bold text-lg mb-2">{template.name}</h3>
                                <p className="text-sm text-gray-600 bg-gray-100 p-2 rounded-md">{template.body}</p>
                            </div>
                            <div className="flex justify-end mt-4">
                                <Button size="sm">Use Template</Button>
                            </div>
                        </div>
                    ))}
                </div>
            </DialogContent>
        </Dialog>

        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}><DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto"><DialogHeader className="pb-4 border-b border-gray-200 mb-4"><DialogTitle className="text-2xl font-bold">{editingTemplate ? 'Edit Template' : 'Create New Template'}</DialogTitle><DialogDescription>Design your template and submit it for approval by Meta.</DialogDescription></DialogHeader><div className="flex flex-col md:flex-row gap-8 py-4"><div className="md:w-1/2 space-y-4 pr-4">{/* Form Fields */}<div className="space-y-2"><Label htmlFor="name">Template Name</Label><input id="name" name="name" value={formData.name} onChange={handleInputChange} placeholder="e.g. order_confirmation" className="w-full p-2 border rounded-md" /><p className="text-xs text-gray-500">Lowercase letters and underscores only.</p></div><div className="space-y-2"><Label htmlFor="category">Category</Label><select id="category" name="category" value={formData.category} onChange={handleInputChange} className="w-full p-2 border rounded-md"><option value="UTILITY">Utility</option><option value="MARKETING">Marketing</option><option value="AUTHENTICATION">Authentication</option></select></div><div className="space-y-2"><Label htmlFor="language">Language</Label><select id="language" name="language" value={formData.language} onChange={handleInputChange} className="w-full p-2 border rounded-md"><option value="en_US">English (US)</option><option value="es_ES">Spanish (Spain)</option><option value="fr_FR">French (France)</option></select></div><div className="p-4 border rounded-lg space-y-2"><Label>Header (Optional)</Label><select name="type" value={formData.header.type} onChange={handleHeaderChange} className="w-full p-2 border rounded-md text-sm mb-2"><option value="NONE">None</option><option value="TEXT">Text</option><option value="IMAGE">Image</option><option value="VIDEO">Video</option><option value="DOCUMENT">Document</option></select>{formData.header.type === 'TEXT' && <input name="text" value={formData.header.text} onChange={handleHeaderChange} placeholder="Header text (60 chars)..." className="w-full p-2 border rounded-md" maxLength={60} />}</div><div className="space-y-2"><Label htmlFor="body">Body</Label><textarea id="body" name="body" value={formData.body} onChange={handleInputChange} placeholder="Message body with {{1}} variables..." className="w-full p-2 border rounded-md min-h-[100px]" maxLength={1024}/></div><div className="space-y-2"><Label htmlFor="footer">Footer (Optional)</Label><input id="footer" name="footer" value={formData.footer} onChange={handleInputChange} placeholder="Footer text (60 chars)..." className="w-full p-2 border rounded-md" maxLength={60} /></div><div className="p-4 border rounded-lg space-y-4"><Label>Buttons (Optional)</Label><div className="space-y-2">{formData.buttons.map((btn, i) => (<div key={i} className="p-2 border rounded-md space-y-2 relative"><Button variant="ghost" size="icon" onClick={() => removeButton(i)} className="absolute top-1 right-1 h-6 w-6"><X className="w-4 h-4 text-red-500" /></Button><input type="text" name="text" value={btn.text} onChange={(e) => handleButtonChange(i, e)} placeholder="Button Text (25 chars)" maxLength={25} className="w-full p-2 border rounded-md" />{btn.type === 'URL' && <input type="text" name="url" value={btn.url || ''} onChange={(e) => handleButtonChange(i,e)} placeholder="https://example.com/..." className="w-full p-2 border rounded-md" />}{btn.type === 'PHONE_NUMBER' && <input type="text" name="phoneNumber" value={btn.phoneNumber || ''} onChange={(e) => handleButtonChange(i,e)} placeholder="+15550123456" className="w-full p-2 border rounded-md" />}<p className="text-xs text-gray-500 uppercase">{btn.type.replace('_', ' ')}</p></div>))}</div><div className="flex gap-2 flex-wrap"><Button variant="outline" size="sm" onClick={() => addButton('QUICK_REPLY')}>+ Quick Reply</Button><Button variant="outline" size="sm" onClick={() => addButton('URL')}>+ URL Button</Button><Button variant="outline" size="sm" onClick={() => addButton('PHONE_NUMBER')}>+ Phone Button</Button></div><p className="text-xs text-gray-500">Max 3 buttons.</p></div></div><div className="md:w-1/2 flex flex-col items-center pt-4 md:pt-0"><Label className="text-center block mb-2">Live Preview</Label><div className="sticky top-4 flex items-center justify-center"><TemplatePreview header={formData.header} body={formData.body} footer={formData.footer} buttons={formData.buttons} /></div></div></div><DialogFooter><DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose><Button onClick={handleSaveTemplate}>Save Template</Button></DialogFooter></DialogContent></Dialog>
      </div></>
  );
};

export default Templates;