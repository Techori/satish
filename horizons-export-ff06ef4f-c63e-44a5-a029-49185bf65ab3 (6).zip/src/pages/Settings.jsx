import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { 
  Settings as SettingsIcon, 
  Bell, 
  Shield, 
  Smartphone, 
  Globe, 
  CreditCard,
  Key,
  Database,
  MessageCircle,
  CheckCircle,
  XCircle,
  Lock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import AdminControls from '@/components/AdminControls';

const Settings = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
  });
  const [isNumberConnected, setIsNumberConnected] = useState(false);
  // In a real app, this would be checked against user role in metadata or database
  const isAdmin = true; // user?.app_metadata?.role === 'admin';

  const fetchConnectionStatus = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('profiles')
      .select('is_whatsapp_connected')
      .eq('id', user.id)
      .single();
    
    if (error) {
      console.error('Error fetching connection status:', error);
    } else if (data) {
      setIsNumberConnected(data.is_whatsapp_connected);
    }
  }, [user]);

  useEffect(() => {
    fetchConnectionStatus();
  }, [fetchConnectionStatus]);

  const handleSave = () => {
    toast({
      title: "Settings Saved! ✅",
      description: "Your preferences have been updated successfully.",
    });
  };

  const handleAction = (action) => {
    toast({
      title: "🚧 Feature Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const WhatsAppAPISettings = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-bold text-gray-900">WhatsApp Business API</h3>
      {isNumberConnected ? (
        <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded-r-lg">
          <div className="flex items-center">
            <CheckCircle className="h-6 w-6 text-green-600 mr-3" />
            <div>
              <h4 className="font-semibold text-green-800">API Connected</h4>
              <p className="text-sm text-green-700">Your number +1 234 567 8900 is active.</p>
            </div>
          </div>
          <div className="mt-4">
            <Button variant="outline" className="rounded-xl">Manage Connection</Button>
          </div>
        </div>
      ) : (
        <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded-r-lg">
          <div className="flex items-center">
            <XCircle className="h-6 w-6 text-orange-600 mr-3" />
            <div>
              <h4 className="font-semibold text-orange-800">API Not Connected</h4>
              <p className="text-sm text-orange-700">Connect your WhatsApp number to start messaging.</p>
            </div>
          </div>
          <div className="mt-4">
            <Link to="/whatsapp-setup">
              <Button className="whatsapp-gradient text-white rounded-xl">Connect Now</Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <>
      <Helmet>
        <title>Settings - WhatsApp Business Platform</title>
        <meta name="description" content="Configure your WhatsApp Business platform settings, notifications, and integrations." />
      </Helmet>

      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Settings</h2>
          <p className="text-gray-600 mt-1">Manage your account and platform preferences</p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-effect rounded-2xl shadow-lg overflow-hidden"
        >
          <Tabs defaultValue="general" className="w-full">
            <div className="border-b border-gray-200 bg-transparent overflow-x-auto">
              <TabsList className="w-full justify-start rounded-none p-0 h-auto flex-nowrap">
                <TabsTrigger 
                  value="general" 
                  className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 whitespace-nowrap"
                >
                  <SettingsIcon className="w-4 h-4 mr-2" />
                  General
                </TabsTrigger>
                <TabsTrigger 
                  value="whatsapp"
                  className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  WhatsApp API
                </TabsTrigger>
                <TabsTrigger 
                  value="notifications"
                  className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 whitespace-nowrap"
                >
                  <Bell className="w-4 h-4 mr-2" />
                  Notifications
                </TabsTrigger>
                <TabsTrigger 
                  value="security"
                  className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 whitespace-nowrap"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Security
                </TabsTrigger>
                <TabsTrigger 
                  value="integrations"
                  className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 whitespace-nowrap"
                >
                  <Smartphone className="w-4 h-4 mr-2" />
                  Integrations
                </TabsTrigger>
                {isAdmin && (
                  <TabsTrigger 
                    value="admin"
                    className="data-[state=active]:bg-yellow-50 data-[state=active]:text-yellow-700 data-[state=active]:border-b-2 data-[state=active]:border-yellow-600 rounded-none px-6 py-4 whitespace-nowrap font-semibold"
                  >
                    <Lock className="w-4 h-4 mr-2" />
                    Admin Controls
                  </TabsTrigger>
                )}
              </TabsList>
            </div>

            <TabsContent value="general" className="p-6 space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Business Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="businessName">Business Name</Label>
                    <input id="businessName" type="text" defaultValue="WhatsBiz" className="w-full mt-2 px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500" />
                  </div>
                  <div>
                    <Label htmlFor="industry">Industry</Label>
                    <input id="industry" type="text" defaultValue="Technology" className="w-full mt-2 px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500" />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <input id="phone" type="tel" defaultValue="+1 234 567 8900" className="w-full mt-2 px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500" />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <input id="email" type="email" defaultValue="admin@whatsbiz.com" className="w-full mt-2 px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="description">Business Description</Label>
                  <textarea id="description" rows={4} defaultValue="We help businesses communicate better with their customers through WhatsApp." className="w-full mt-2 px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500" />
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Regional Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="timezone">Timezone</Label>
                    <select id="timezone" className="w-full mt-2 px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500">
                      <option>UTC-5 (Eastern Time)</option>
                      <option>UTC-8 (Pacific Time)</option>
                      <option>UTC+0 (GMT)</option>
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="language">Language</Label>
                    <select id="language" className="w-full mt-2 px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500">
                      <option>English</option>
                      <option>Spanish</option>
                      <option>French</option>
                    </select>
                  </div>
                </div>
              </div>
              <Button onClick={handleSave} className="whatsapp-gradient text-white rounded-xl">Save Changes</Button>
            </TabsContent>

            <TabsContent value="whatsapp" className="p-6 space-y-6">
              <WhatsAppAPISettings />
            </TabsContent>

            <TabsContent value="notifications" className="p-6 space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Notification Preferences</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-white/50 rounded-xl">
                    <div className="flex-1">
                      <Label htmlFor="email-notif" className="text-base font-medium">Email Notifications</Label>
                      <p className="text-sm text-gray-600 mt-1">Receive notifications via email</p>
                    </div>
                    <Switch id="email-notif" checked={notifications.email} onCheckedChange={(checked) => setNotifications({ ...notifications, email: checked })} />
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/50 rounded-xl">
                    <div className="flex-1">
                      <Label htmlFor="push-notif" className="text-base font-medium">Push Notifications</Label>
                      <p className="text-sm text-gray-600 mt-1">Receive push notifications in browser</p>
                    </div>
                    <Switch id="push-notif" checked={notifications.push} onCheckedChange={(checked) => setNotifications({ ...notifications, push: checked })} />
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/50 rounded-xl">
                    <div className="flex-1">
                      <Label htmlFor="sms-notif" className="text-base font-medium">SMS Notifications</Label>
                      <p className="text-sm text-gray-600 mt-1">Receive notifications via SMS</p>
                    </div>
                    <Switch id="sms-notif" checked={notifications.sms} onCheckedChange={(checked) => setNotifications({ ...notifications, sms: checked })} />
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Notification Types</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {['New messages', 'Broadcast sent', 'Team mentions', 'System updates', 'Weekly reports', 'Failed deliveries'].map((type, index) => (
                    <div key={index} className="flex items-center space-x-3 p-4 bg-white/50 rounded-xl">
                      <Switch id={`notif-${index}`} defaultChecked />
                      <Label htmlFor={`notif-${index}`} className="cursor-pointer">{type}</Label>
                    </div>
                  ))}
                </div>
              </div>
              <Button onClick={handleSave} className="whatsapp-gradient text-white rounded-xl">Save Preferences</Button>
            </TabsContent>

            <TabsContent value="security" className="p-6 space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Password & Authentication</h3>
                <div className="space-y-4">
                  <Button onClick={() => handleAction('password')} variant="outline" className="w-full justify-start rounded-xl"><Key className="w-4 h-4 mr-2" />Change Password</Button>
                  <Button onClick={() => handleAction('2fa')} variant="outline" className="w-full justify-start rounded-xl"><Shield className="w-4 h-4 mr-2" />Enable Two-Factor Authentication</Button>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">API Access</h3>
                <div className="bg-white/50 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-base font-medium">API Key</Label>
                    <Button onClick={() => handleAction('regenerate')} variant="outline" size="sm" className="rounded-xl">Regenerate</Button>
                  </div>
                  <code className="block p-3 bg-gray-100 rounded-lg text-sm font-mono break-all">wbp_1234567890abcdef1234567890abcdef</code>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Session Management</h3>
                <Button onClick={() => handleAction('logout')} variant="outline" className="w-full justify-start rounded-xl text-red-600 hover:bg-red-50"><Database className="w-4 h-4 mr-2" />Log Out All Devices</Button>
              </div>
            </TabsContent>

            <TabsContent value="integrations" className="p-6 space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Connected Services</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { name: 'CRM Integration', status: 'Not Connected', icon: Database, color: 'from-blue-500 to-blue-600' },
                    { name: 'Payment Gateway', status: 'Connected', icon: CreditCard, color: 'from-purple-500 to-purple-600' },
                    { name: 'Analytics Platform', status: 'Connected', icon: Globe, color: 'from-orange-500 to-orange-600' },
                  ].map((service, index) => (
                    <div key={index} className="bg-white/50 rounded-xl p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center shadow-lg`}>
                          <service.icon className="w-6 h-6 text-white" />
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${service.status === 'Connected' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>{service.status}</span>
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-2">{service.name}</h4>
                      <Button onClick={() => handleAction('integration')} variant="outline" size="sm" className="w-full rounded-xl">{service.status === 'Connected' ? 'Configure' : 'Connect'}</Button>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900">Webhooks</h3>
                <div className="bg-white/50 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-4">
                    <Label className="text-base font-medium">Webhook URL</Label>
                    <Button onClick={() => handleAction('webhook')} variant="outline" size="sm" className="rounded-xl">Add Webhook</Button>
                  </div>
                  <p className="text-sm text-gray-600">Configure webhooks to receive real-time updates about events in your account.</p>
                </div>
              </div>
            </TabsContent>
            
            {isAdmin && (
              <TabsContent value="admin" className="p-6">
                <AdminControls />
              </TabsContent>
            )}
          </Tabs>
        </motion.div>
      </div>
    </>
  );
};

export default Settings;