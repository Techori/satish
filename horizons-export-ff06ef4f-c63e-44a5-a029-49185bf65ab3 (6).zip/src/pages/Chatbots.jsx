import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Plus, Play, Pause, Settings, Trash2, MessageSquare, CornerDownLeft, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const Chatbots = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [chatbots, setChatbots] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBot, setEditingBot] = useState(null);
  const [loading, setLoading] = useState(true);

  const initialFormData = {
    name: '',
    trigger: { type: 'first_contact', value: '' },
    steps: [{ type: 'reply', content: '' }],
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchChatbots = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('chatbots')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast({ title: 'Error fetching chatbots', description: error.message, variant: 'destructive' });
    } else {
      setChatbots(data);
    }
    setLoading(false);
  }, [user, toast]);

  useEffect(() => {
    fetchChatbots();
  }, [fetchChatbots]);
  
  const handleOpenModal = (bot = null) => {
    if (bot) {
      setEditingBot(bot);
      setFormData({
        name: bot.name,
        trigger: bot.trigger || { type: 'first_contact', value: '' },
        steps: bot.steps || [{ type: 'reply', content: '' }],
      });
    } else {
      setEditingBot(null);
      setFormData(initialFormData);
    }
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    if (!user) return;
    if (!formData.name) {
      toast({ title: "Validation Error", description: "Chatbot Name is required.", variant: "destructive" });
      return;
    }
    
    const botData = { ...formData, user_id: user.id };
    let error;

    if (editingBot) {
      ({ error } = await supabase.from('chatbots').update(botData).eq('id', editingBot.id));
      toast({ title: "Chatbot Updated!", description: `${formData.name} has been successfully updated.` });
    } else {
      ({ error } = await supabase.from('chatbots').insert({ ...botData, status: 'Paused', responseRate: 'N/A' }));
      toast({ title: "Chatbot Created!", description: `${formData.name} has been created. Activate it to start.` });
    }

    if (error) {
      toast({ title: 'Error saving chatbot', description: error.message, variant: 'destructive' });
    } else {
      await fetchChatbots();
      setIsModalOpen(false);
    }
  };
  
  const handleDelete = async (botId) => {
    const { error } = await supabase.from('chatbots').delete().eq('id', botId);
    if (error) {
      toast({ title: 'Error deleting chatbot', description: error.message, variant: 'destructive' });
    } else {
      setChatbots(chatbots.filter(b => b.id !== botId));
      toast({ title: "Chatbot Deleted", variant: "destructive" });
    }
  };

  const toggleStatus = async (bot) => {
    const newStatus = bot.status === 'Active' ? 'Paused' : 'Active';
    const { error } = await supabase.from('chatbots').update({ status: newStatus }).eq('id', bot.id);
    if (error) {
      toast({ title: 'Error updating status', description: error.message, variant: 'destructive' });
    } else {
      setChatbots(chatbots.map(b => b.id === bot.id ? { ...b, status: newStatus } : b));
      toast({ title: `Bot ${newStatus}`, description: `${bot.name} is now ${newStatus.toLowerCase()}.` });
    }
  };
  
  const handleFormChange = (e) => setFormData(p => ({ ...p, [e.target.name]: e.target.value }));
  const handleTriggerChange = (e) => setFormData(p => ({ ...p, trigger: { ...p.trigger, [e.target.name]: e.target.value } }));
  const handleStepChange = (index, value) => {
    const newSteps = [...formData.steps];
    newSteps[index].content = value;
    setFormData(p => ({...p, steps: newSteps}));
  };
  const addStep = () => setFormData(p => ({...p, steps: [...p.steps, {type: 'reply', content: ''}]}));
  const removeStep = (index) => setFormData(p => ({...p, steps: p.steps.filter((_, i) => i !== index)}));

  const stats = useMemo(() => ({
    active: chatbots.filter(b => b.status === 'Active').length,
    totalConversations: chatbots.reduce((sum, b) => sum + (b.conversations || 0), 0),
  }), [chatbots]);

  return (
    <>
      <Helmet>
        <title>Chatbots - WhatsApp Business Platform</title>
        <meta name="description" content="Create and manage AI-powered chatbots to automate customer conversations on WhatsApp." />
      </Helmet>

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div><h1 className="text-3xl font-bold text-gray-900">Chatbot Automation</h1><p className="text-gray-600 mt-1">Automate conversations with AI-powered chatbots</p></div>
          <Button onClick={() => handleOpenModal()} className="whatsapp-gradient text-white rounded-xl"><Plus className="w-4 h-4 mr-2" />Create Chatbot</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-effect rounded-xl p-6 shadow-lg">
                <div className="flex items-start justify-between">
                    <div>
                        <p className="text-sm text-gray-600 font-medium">Active Bots</p>
                        <p className="text-2xl font-bold mt-1 bg-gradient-to-r from-blue-500 to-blue-600 bg-clip-text text-transparent">{stats.active}</p>
                    </div>
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg"><Bot className="w-6 h-6 text-white" /></div>
                </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-effect rounded-xl p-6 shadow-lg">
                 <div className="flex items-start justify-between">
                    <div>
                        <p className="text-sm text-gray-600 font-medium">Total Conversations</p>
                        <p className="text-2xl font-bold mt-1 bg-gradient-to-r from-green-500 to-green-600 bg-clip-text text-transparent">{stats.totalConversations.toLocaleString()}</p>
                    </div>
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center shadow-lg"><MessageSquare className="w-6 h-6 text-white" /></div>
                </div>
            </motion.div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64"><Loader2 className="w-12 h-12 text-green-500 animate-spin" /></div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <AnimatePresence>
              {chatbots.map((bot, index) => (
                <motion.div key={bot.id} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ delay: index * 0.05 }} className="glass-effect rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3"><div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center shadow-lg"><Bot className="w-6 h-6 text-white" /></div>
                      <div><h3 className="text-lg font-bold text-gray-900">{bot.name}</h3><span className={`inline-block px-2 py-1 rounded-full text-xs font-medium mt-1 ${bot.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>{bot.status}</span></div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button variant="ghost" size="icon" onClick={() => toggleStatus(bot)}>{bot.status === 'Active' ? <Pause className="w-5 h-5 text-gray-600" /> : <Play className="w-5 h-5 text-green-600" />}</Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild><Button variant="ghost" size="icon"><Trash2 className="w-5 h-5 text-red-500" /></Button></AlertDialogTrigger>
                        <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Are you sure?</AlertDialogTitle><AlertDialogDescription>This will permanently delete the "{bot.name}" chatbot and its data.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => handleDelete(bot.id)}>Delete</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-4"><div className="bg-white/50 rounded-xl p-3"><p className="text-xs text-gray-600 mb-1">Conversations</p><p className="text-xl font-bold text-gray-900">{bot.conversations.toLocaleString()}</p></div><div className="bg-white/50 rounded-xl p-3"><p className="text-xs text-gray-600 mb-1">Response Rate</p><p className="text-xl font-bold text-green-600">{bot.response_rate}</p></div></div>
                  <Button onClick={() => handleOpenModal(bot)} className="w-full whatsapp-gradient text-white rounded-xl"><Settings className="w-4 h-4 mr-2" />Edit Flow</Button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
      
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle className="text-2xl font-bold">{editingBot ? 'Edit Chatbot' : 'Create New Chatbot'}</DialogTitle><DialogDescription>Build an automated conversation flow for your customers.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2"><Label htmlFor="name">Chatbot Name</Label><input id="name" name="name" value={formData.name} onChange={handleFormChange} placeholder="e.g., Welcome Bot" className="w-full p-2 border rounded-md" /></div>
            <div className="p-4 border rounded-lg space-y-3">
              <Label>Trigger</Label>
              <p className="text-sm text-gray-500">When should this bot activate?</p>
              <div className="flex gap-4">
                <select name="type" value={formData.trigger.type} onChange={handleTriggerChange} className="p-2 border rounded-md">
                  <option value="first_contact">First Contact</option>
                  <option value="keywords">Keywords</option>
                </select>
                {formData.trigger.type === 'keywords' && <input name="value" value={formData.trigger.value} onChange={handleTriggerChange} placeholder="e.g., help, support" className="w-full p-2 border rounded-md" />}
              </div>
            </div>
            <div className="p-4 border rounded-lg space-y-4">
              <Label>Conversation Flow</Label>
              <div className="space-y-3">
                {formData.steps.map((step, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-2"><CornerDownLeft className="w-4 h-4 text-gray-400"/></div>
                    <div className="flex-grow space-y-2 relative">
                       <textarea value={step.content} onChange={(e) => handleStepChange(index, e.target.value)} placeholder={`Step ${index + 1}: Automated reply...`} className="w-full p-2 border rounded-md min-h-[60px]" />
                        {formData.steps.length > 1 && <Button variant="ghost" size="icon" onClick={() => removeStep(index)} className="absolute top-1 right-1 h-6 w-6"><X className="w-4 h-4 text-red-500" /></Button>}
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" onClick={addStep}><Plus className="w-4 h-4 mr-2"/>Add Step</Button>
            </div>
          </div>
          <DialogFooter><DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose><Button onClick={handleSave}>Save Chatbot</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Chatbots;