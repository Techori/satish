
import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Plus, Send, Users, BarChart2, RefreshCw, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { cn } from '@/lib/utils';
import BroadcastWizard from '@/components/broadcasts/BroadcastWizard';
import BroadcastAnalytics from '@/components/broadcasts/BroadcastAnalytics';

const Broadcasts = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [broadcasts, setBroadcasts] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);
  const [selectedBroadcast, setSelectedBroadcast] = useState(null);

  const fetchBroadcasts = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('broadcasts')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else setBroadcasts(data);
    setLoading(false);
  }, [user, toast]);

  const fetchTemplates = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('templates')
      .select('*')
      .eq('user_id', user.id)
      .eq('status', 'Approved');
    if (data) setTemplates(data);
  }, [user]);

  useEffect(() => {
    fetchBroadcasts();
    fetchTemplates();
  }, [fetchBroadcasts, fetchTemplates]);

  const handleCreateBroadcast = async (wizardData, updateProgress) => {
    try {
      const { data: broadcast, error: bError } = await supabase.from('broadcasts').insert({
        user_id: user.id,
        name: wizardData.name,
        status: 'Processing',
        template_name: wizardData.selectedTemplate.name,
        message: wizardData.selectedTemplate.body, 
        audience: wizardData.audienceType === 'csv' ? 'CSV Import' : 'Database Contacts',
        recipients: 0,
        sent_at: new Date().toISOString()
      }).select().single();

      if (bError) throw bError;

      let recipientList = [];
      if (wizardData.audienceType === 'csv') {
        recipientList = wizardData.recipients;
      } else {
        let query = supabase.from('contacts').select('name, number').eq('user_id', user.id);
        if (wizardData.selectedTag) {
             query = query.contains('tags', [wizardData.selectedTag]);
        }
        const { data: contacts } = await query;
        recipientList = contacts || [];
      }

      if (recipientList.length === 0) {
        throw new Error("No recipients found for the selected audience.");
      }

      const BATCH_SIZE = 50;
      const total = recipientList.length;
      let processed = 0;

      for (let i = 0; i < total; i += BATCH_SIZE) {
        const chunk = recipientList.slice(i, i + BATCH_SIZE);
        
        const recipientsPayload = chunk.map(r => ({
            broadcast_id: broadcast.id,
            user_id: user.id,
            phone_number: r.number,
            name: r.name,
            status: 'sent',
            created_at: new Date().toISOString()
        }));

        const { error: rError } = await supabase.from('broadcast_recipients').insert(recipientsPayload);
        if (rError) console.error("Batch insert error", rError);

        processed += chunk.length;
        updateProgress((processed / total) * 100);
        
        await new Promise(r => setTimeout(r, 300)); 
      }

      await supabase.from('broadcasts').update({
        status: 'Sent',
        recipients: total,
        delivered: 0,
        read_count: 0
      }).eq('id', broadcast.id);

      toast({ title: "Broadcast Sent!", description: `Successfully processed ${total} recipients.` });
      fetchBroadcasts();

    } catch (error) {
      console.error(error);
      toast({ title: "Broadcast Failed", description: error.message, variant: "destructive" });
    }
  };

  const getStatusBadge = (status) => {
    const styles = {
      Sent: 'bg-green-100 text-green-700 hover:bg-green-100',
      Processing: 'bg-blue-100 text-blue-700 hover:bg-blue-100 animate-pulse',
      Draft: 'bg-gray-100 text-gray-700 hover:bg-gray-100',
      Scheduled: 'bg-yellow-100 text-yellow-700 hover:bg-yellow-100'
    };
    return <Badge className={styles[status] || styles.Draft}>{status}</Badge>;
  };

  return (
    <>
      <Helmet>
        <title>Broadcasts - Wabista Business Platform</title>
      </Helmet>
      
      <div className="space-y-6 p-2">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Broadcast Campaigns</h1>
            <p className="text-gray-600 mt-1">Manage high-volume messaging campaigns.</p>
          </div>
          <Button onClick={() => setIsWizardOpen(true)} className="whatsapp-gradient text-white shadow-lg">
            <Plus className="w-4 h-4 mr-2" /> New Broadcast
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-gray-500">Total Campaigns</CardTitle></CardHeader>
                <CardContent><div className="text-2xl font-bold">{broadcasts.length}</div></CardContent>
            </Card>
            <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-gray-500">Messages Sent (All Time)</CardTitle></CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold text-green-600">
                        {broadcasts.reduce((acc, curr) => acc + (curr.recipients || 0), 0).toLocaleString()}
                    </div>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-gray-500">Avg Read Rate</CardTitle></CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold text-purple-600">
                       {broadcasts.length ? Math.round(
                           broadcasts.reduce((acc, b) => acc + (b.recipients ? (b.read_count/b.recipients) : 0), 0) / broadcasts.length * 100
                       ) : 0}%
                    </div>
                </CardContent>
            </Card>
        </div>

        <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
            <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
                <h3 className="font-semibold text-gray-900">Campaign History</h3>
                <Button variant="ghost" size="sm" onClick={fetchBroadcasts} disabled={loading}>
                    <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
                </Button>
            </div>
            
            {broadcasts.length === 0 && !loading ? (
                <div className="p-12 text-center text-gray-500">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Send className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900">No broadcasts yet</h3>
                    <p className="mt-1">Create your first campaign to reach your customers.</p>
                </div>
            ) : (
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-50 border-b text-xs uppercase text-gray-500 font-semibold">
                            <tr>
                                <th className="px-6 py-3">Campaign Name</th>
                                <th className="px-6 py-3">Status</th>
                                <th className="px-6 py-3">Audience</th>
                                <th className="px-6 py-3">Recipients</th>
                                <th className="px-6 py-3">Sent At</th>
                                <th className="px-6 py-3 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {broadcasts.map((broadcast) => (
                                <motion.tr 
                                    key={broadcast.id} 
                                    initial={{ opacity: 0 }} 
                                    animate={{ opacity: 1 }}
                                    className="hover:bg-gray-50 transition-colors"
                                >
                                    <td className="px-6 py-4 font-medium text-gray-900">{broadcast.name}</td>
                                    <td className="px-6 py-4">{getStatusBadge(broadcast.status)}</td>
                                    <td className="px-6 py-4 text-gray-500 flex items-center gap-2">
                                        {broadcast.audience?.includes('CSV') ? <BarChart2 className="w-4 h-4"/> : <Users className="w-4 h-4"/>}
                                        {broadcast.audience}
                                    </td>
                                    <td className="px-6 py-4 text-gray-500">{broadcast.recipients?.toLocaleString() || '-'}</td>
                                    <td className="px-6 py-4 text-gray-500">
                                        {broadcast.sent_at ? new Date(broadcast.sent_at).toLocaleDateString() : '-'}
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <Button 
                                            variant="outline" 
                                            size="sm" 
                                            onClick={() => { setSelectedBroadcast(broadcast); setIsAnalyticsOpen(true); }}
                                        >
                                            View Analytics
                                        </Button>
                                    </td>
                                </motion.tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
      </div>

      <BroadcastWizard 
        open={isWizardOpen} 
        onOpenChange={setIsWizardOpen}
        templates={templates}
        onComplete={handleCreateBroadcast}
      />

      <BroadcastAnalytics
        open={isAnalyticsOpen}
        onOpenChange={setIsAnalyticsOpen}
        broadcast={selectedBroadcast}
      />
    </>
  );
};

export default Broadcasts;
