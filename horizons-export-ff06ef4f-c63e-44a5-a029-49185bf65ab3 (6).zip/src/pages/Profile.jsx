import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { User, Mail, Phone, Lock, Bell, Shield, Key, Download, Edit, X, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

const Profile = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [profileData, setProfileData] = useState({
    full_name: '',
    email: '',
    avatar_url: '',
  });
  const [apiKey, setApiKey] = useState("**************************abcd");

  const fetchProfile = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('profiles')
      .select('full_name, avatar_url')
      .eq('id', user.id)
      .single();
    
    if (error) {
      console.error('Error fetching profile:', error);
    } else if (data) {
      setProfileData({
        full_name: data.full_name || '',
        email: user.email || '',
        avatar_url: data.avatar_url || '',
      });
    }
  }, [user]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setProfileData(prev => ({ ...prev, [id]: value }));
  };

  const handleUpdateProfile = async () => {
    if (!user) return;
    const { error } = await supabase
      .from('profiles')
      .update({ full_name: profileData.full_name, avatar_url: profileData.avatar_url })
      .eq('id', user.id);
    
    if (error) {
      toast({ title: 'Error', description: 'Failed to update profile.', variant: 'destructive' });
    } else {
      toast({ title: 'Success!', description: 'Your profile has been updated.' });
    }
  };
  
  const handlePhotoChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      toast({
        title: "Photo Updated!",
        description: "Your new profile photo looks great. ✨",
      });
    }
  };

  const handleAction = (feature) => {
    toast({
      title: '🚧 Feature Coming Soon!',
      description: `The "${feature}" feature is not implemented yet. You can request it in your next prompt! 🚀`,
    });
  };
  
  const handleRegenerateApiKey = () => {
    const newKey = `wh_live_${[...Array(24)].map(() => Math.random().toString(36)[2]).join('')}`;
    setApiKey(newKey);
    toast({
        title: "API Key Regenerated!",
        description: "Your new API key has been generated successfully.",
    });
  };

  return (
    <>
      <Helmet>
        <title>Admin Profile - WhatsApp Business Platform</title>
        <meta name="description" content="Manage your admin profile, security settings, and notification preferences." />
      </Helmet>
      <div className="space-y-8">
        <motion.div 
          initial={{ opacity: 0, y: -20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="flex flex-col md:flex-row items-center gap-6"
        >
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-green-400 to-emerald-600 rounded-full flex items-center justify-center text-white text-5xl font-bold ring-4 ring-white shadow-lg">
              {profileData.full_name ? profileData.full_name.charAt(0).toUpperCase() : (user?.email?.charAt(0).toUpperCase() || 'A')}
            </div>
             <label htmlFor="photo-upload" className="absolute bottom-1 right-1 rounded-full bg-white text-gray-800 hover:bg-gray-100 shadow-md cursor-pointer p-2">
                <Edit className="w-4 h-4" />
                <input id="photo-upload" type="file" className="hidden" accept="image/*" onChange={handlePhotoChange} />
            </label>
          </div>
          <div>
            <h2 className="text-3xl font-bold text-gray-900">{profileData.full_name || 'User'}</h2>
            <p className="text-gray-600">Administrator</p>
            <div className="flex items-center gap-4 mt-2">
              <span className="flex items-center text-sm text-gray-500"><Mail className="w-4 h-4 mr-2" /> {profileData.email}</span>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Profile & Security */}
          <div className="lg:col-span-2 space-y-8">
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }} className="glass-effect rounded-2xl p-6 shadow-lg">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center"><User className="mr-2" /> Profile Information</h3>
              <div className="space-y-4">
                <div>
                    <Label htmlFor="full_name">Full Name</Label>
                    <input id="full_name" value={profileData.full_name} onChange={handleInputChange} className="w-full mt-1 p-2 border rounded-md" />
                </div>
                <div>
                    <Label htmlFor="email">Email Address</Label>
                    <input id="email" type="email" value={profileData.email} readOnly className="w-full mt-1 p-2 border rounded-md bg-gray-100" />
                </div>
                <div className="text-right">
                    <Button className="whatsapp-gradient" onClick={handleUpdateProfile}>Update Profile</Button>
                </div>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="glass-effect rounded-2xl p-6 shadow-lg">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center"><Lock className="mr-2" /> Security Settings</h3>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                    <div>
                        <Label className="font-semibold">Change Password</Label>
                        <p className="text-sm text-gray-500">Update your password regularly to keep your account secure.</p>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline">Change</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Change Password</DialogTitle>
                          <DialogDescription>Enter your current and new password below.</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <input type="password" placeholder="Current Password" className="p-2 border rounded-md" />
                          <input type="password" placeholder="New Password" className="p-2 border rounded-md" />
                          <input type="password" placeholder="Confirm New Password" className="p-2 border rounded-md" />
                        </div>
                        <DialogFooter>
                          <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                          <Button onClick={() => toast({ title: "Success", description: "Password changed successfully!" })}>Save Changes</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                </div>
                 <div className="flex items-center justify-between">
                    <div>
                        <Label className="font-semibold">Two-Factor Authentication (2FA)</Label>
                        <p className="text-sm text-gray-500">Add an extra layer of security to your account.</p>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="whatsapp-gradient">Enable 2FA</Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Enable Two-Factor Authentication</DialogTitle>
                          <DialogDescription>Scan the QR code with your authenticator app.</DialogDescription>
                        </DialogHeader>
                        <div className="flex flex-col items-center justify-center gap-4 py-4">
                            <div className="w-40 h-40 bg-gray-200 flex items-center justify-center">
                                <p className="text-gray-500 text-sm">QR Code Placeholder</p>
                            </div>
                            <input placeholder="Enter 6-digit code" className="p-2 border rounded-md text-center" />
                        </div>
                        <DialogFooter>
                          <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                          <Button onClick={() => toast({ title: "Success", description: "2FA enabled successfully!" })}>Verify & Enable</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Notifications & API */}
          <div className="space-y-8">
             <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }} className="glass-effect rounded-2xl p-6 shadow-lg">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center"><Bell className="mr-2" /> Notification Settings</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="new-message-notif">New Messages</Label>
                  <Switch id="new-message-notif" defaultChecked onCheckedChange={() => handleAction('Toggle Notifications')} />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="broadcast-notif">Broadcast Reports</Label>
                  <Switch id="broadcast-notif" onCheckedChange={() => handleAction('Toggle Notifications')} />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="system-alert-notif">System Alerts</Label>
                  <Switch id="system-alert-notif" defaultChecked onCheckedChange={() => handleAction('Toggle Notifications')} />
                </div>
              </div>
            </motion.div>
            
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }} className="glass-effect rounded-2xl p-6 shadow-lg">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center"><Key className="mr-2" /> WhatsApp Business API</h3>
              <div className="space-y-4">
                <div>
                  <Label>API Key</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <input readOnly value={apiKey} className="w-full p-2 border rounded-md bg-gray-100 font-mono text-sm" />
                    <Button variant="outline" size="icon" onClick={() => {
                        navigator.clipboard.writeText(apiKey);
                        toast({title: "Copied!", description: "API Key copied to clipboard."});
                    }}><Copy className="w-4 h-4" /></Button>
                  </div>
                </div>
                <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <Button variant="outline" className="w-full">Regenerate API Key</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                                This will invalidate your old API key. Any applications using the old key will no longer be able to access the API. This action cannot be undone.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleRegenerateApiKey} className="bg-destructive hover:bg-destructive/90">Regenerate</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Profile;