import React from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { 
  Activity, 
  Zap, 
  Clock, 
  AlertTriangle 
} from 'lucide-react';

const AdminApiMonitoring = () => {
  // Mock Data
  const hourlyRequests = [
    { time: '00:00', requests: 120 },
    { time: '04:00', requests: 80 },
    { time: '08:00', requests: 450 },
    { time: '12:00', requests: 980 },
    { time: '16:00', requests: 850 },
    { time: '20:00', requests: 340 },
    { time: '23:59', requests: 190 },
  ];

  const endpointUsage = [
    { name: '/messages', count: 4520 },
    { name: '/contacts', count: 1230 },
    { name: '/webhooks', count: 3400 },
    { name: '/auth', count: 560 },
    { name: '/templates', count: 230 },
  ];

  const stats = [
    { label: 'Total Requests (24h)', value: '12,450', change: '+12%', icon: Activity, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Avg Latency', value: '145ms', change: '-5%', icon: Zap, color: 'text-yellow-600', bg: 'bg-yellow-100' },
    { label: 'Error Rate', value: '0.4%', change: '+0.1%', icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-100' },
    { label: 'Uptime', value: '99.99%', change: '0%', icon: Clock, color: 'text-green-600', bg: 'bg-green-100' },
  ];

  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
            <div className="flex justify-between items-start mb-2">
              <div className={`p-2 rounded-lg ${stat.bg}`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                stat.change.startsWith('+') ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
              }`}>
                {stat.change}
              </span>
            </div>
            <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
            <div className="text-xs text-gray-500">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Rate Limit Card */}
        <div className="lg:col-span-1 bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Rate Limit Status</h3>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Global API Limit</span>
                <span className="font-bold text-gray-900">85%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-orange-500 w-[85%] rounded-full" />
              </div>
              <p className="text-xs text-gray-400 mt-1">850 / 1000 req/min</p>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Webhook Capacity</span>
                <span className="font-bold text-gray-900">42%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 w-[42%] rounded-full" />
              </div>
              <p className="text-xs text-gray-400 mt-1">Processing 420 events/sec</p>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
              <h4 className="text-sm font-semibold text-gray-800 mb-1">Optimization Tip</h4>
              <p className="text-xs text-gray-600">
                High traffic detected on /messages endpoint. Consider implementing batch processing for broadcasts.
              </p>
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Request Volume (24h)</h3>
          <div className="h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyRequests}>
                <defs>
                  <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#9ca3af'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#9ca3af'}} />
                <Tooltip />
                <Area type="monotone" dataKey="requests" stroke="#22c55e" strokeWidth={2} fillOpacity={1} fill="url(#colorRequests)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminApiMonitoring;