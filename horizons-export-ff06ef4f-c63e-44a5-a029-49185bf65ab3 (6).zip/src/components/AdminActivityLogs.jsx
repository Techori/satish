import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Clock, 
  User, 
  Settings, 
  Radio, 
  FileText, 
  LogIn, 
  AlertCircle,
  Search,
  Filter
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const AdminActivityLogs = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Mock data for activity logs
  const logs = [
    { id: 1, user: 'John Admin', action: 'Login Successful', type: 'auth', details: 'IP: 192.168.1.1', timestamp: '2023-11-25T10:30:00' },
    { id: 2, user: 'Sarah Support', action: 'Broadcast Sent', type: 'broadcast', details: 'Campaign: Black Friday Promo (5000 recipients)', timestamp: '2023-11-25T10:15:00' },
    { id: 3, user: 'Mike Dev', action: 'API Key Regenerated', type: 'system', details: 'Key ID: sk_...4f9a', timestamp: '2023-11-25T09:45:00' },
    { id: 4, user: 'John Admin', action: 'Template Approved', type: 'template', details: 'Template: welcome_msg_v2', timestamp: '2023-11-24T16:20:00' },
    { id: 5, user: 'Sarah Support', action: 'Exported Contacts', type: 'data', details: 'Format: CSV, Count: 1250', timestamp: '2023-11-24T14:10:00' },
    { id: 6, user: 'System', action: 'Webhook Delivery Failed', type: 'error', details: 'Endpoint: /webhook/msg - 500 Internal Server Error', timestamp: '2023-11-24T11:00:00' },
  ];

  const getIcon = (type) => {
    switch (type) {
      case 'auth': return <LogIn className="w-4 h-4 text-blue-500" />;
      case 'broadcast': return <Radio className="w-4 h-4 text-purple-500" />;
      case 'system': return <Settings className="w-4 h-4 text-orange-500" />;
      case 'template': return <FileText className="w-4 h-4 text-green-500" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const formatTime = (isoString) => {
    return new Date(isoString).toLocaleString();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input 
            placeholder="Search logs..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="all">
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Filter by Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Events</SelectItem>
              <SelectItem value="auth">Authentication</SelectItem>
              <SelectItem value="system">System</SelectItem>
              <SelectItem value="error">Errors</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="border rounded-xl overflow-hidden bg-white">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 text-gray-700 font-semibold border-b">
            <tr>
              <th className="px-6 py-3 w-12">Type</th>
              <th className="px-6 py-3">Action & Details</th>
              <th className="px-6 py-3">User</th>
              <th className="px-6 py-3 text-right">Timestamp</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {logs.map((log) => (
              <motion.tr 
                key={log.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="hover:bg-gray-50 transition-colors"
              >
                <td className="px-6 py-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center bg-gray-100`}>
                    {getIcon(log.type)}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="font-medium text-gray-900">{log.action}</div>
                  <div className="text-gray-500 text-xs font-mono mt-0.5">{log.details}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <User className="w-3 h-3 text-gray-400" />
                    <span className="text-gray-700">{log.user}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-gray-500 text-xs">
                  {formatTime(log.timestamp)}
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="flex justify-center">
        <Button variant="ghost" size="sm" className="text-gray-500">Load More Logs</Button>
      </div>
    </div>
  );
};

export default AdminActivityLogs;