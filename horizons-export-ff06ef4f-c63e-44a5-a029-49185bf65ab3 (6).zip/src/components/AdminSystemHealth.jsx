import React from 'react';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Server, 
  Database, 
  Cloud, 
  RefreshCw 
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const StatusIndicator = ({ status, label, details }) => {
  const getStatusColor = () => {
    switch(status) {
      case 'healthy': return 'text-green-500 bg-green-50 border-green-200';
      case 'degraded': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'down': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-500 bg-gray-50 border-gray-200';
    }
  };

  const getIcon = () => {
    switch(status) {
      case 'healthy': return <CheckCircle className="w-5 h-5" />;
      case 'degraded': return <AlertTriangle className="w-5 h-5" />;
      case 'down': return <XCircle className="w-5 h-5" />;
      default: return <RefreshCw className="w-5 h-5 animate-spin" />;
    }
  };

  return (
    <div className={`flex items-start p-4 rounded-xl border ${getStatusColor()} transition-all`}>
      <div className="mt-0.5 mr-3">
        {getIcon()}
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-center mb-1">
          <h4 className="font-semibold text-sm uppercase tracking-wide">{label}</h4>
          <span className="text-xs font-mono opacity-75 capitalize">{status}</span>
        </div>
        <p className="text-xs opacity-90">{details}</p>
      </div>
    </div>
  );
};

const AdminSystemHealth = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-gray-900">System Status</h3>
        <div className="flex gap-2">
          <span className="text-xs text-gray-500 self-center">Last checked: Just now</span>
          <Button variant="outline" size="sm" className="h-8 w-8 p-0"><RefreshCw className="w-3 h-3" /></Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <StatusIndicator 
          status="healthy" 
          label="WhatsApp Graph API" 
          details="v17.0 connection active. 45ms latency."
        />
        <StatusIndicator 
          status="healthy" 
          label="Database Cluster" 
          details="Primary node active. 12 active connections."
        />
        <StatusIndicator 
          status="degraded" 
          label="Webhook Processor" 
          details="Queue depth slightly elevated (150 pending)."
        />
        <StatusIndicator 
          status="healthy" 
          label="Storage Service" 
          details="S3 bucket accessible. 45% capacity used."
        />
      </div>

      <div className="bg-gray-900 text-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-white/10 rounded-lg">
            <Server className="w-5 h-5 text-green-400" />
          </div>
          <div>
            <h4 className="font-bold">Server Resources</h4>
            <p className="text-xs text-gray-400">Real-time infrastructure metrics</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs mb-1.5 text-gray-300">
              <span>CPU Usage (4 Cores)</span>
              <span>32%</span>
            </div>
            <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500 w-[32%] rounded-full" />
            </div>
          </div>
          
          <div>
            <div className="flex justify-between text-xs mb-1.5 text-gray-300">
              <span>Memory (16GB)</span>
              <span>64%</span>
            </div>
            <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
              <div className="h-full bg-purple-500 w-[64%] rounded-full" />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1.5 text-gray-300">
              <span>Disk I/O</span>
              <span>12MB/s</span>
            </div>
            <div className="h-1.5 bg-gray-700 rounded-full overflow-hidden">
              <div className="h-full bg-green-500 w-[15%] rounded-full" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSystemHealth;