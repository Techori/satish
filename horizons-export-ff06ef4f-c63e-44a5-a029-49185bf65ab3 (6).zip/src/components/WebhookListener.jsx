import React, { useEffect } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { webhookService } from '@/services/webhookService';
import { useToast } from '@/components/ui/use-toast';
import { MessageSquare, User } from 'lucide-react';

const WebhookListener = () => {
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) return;

    const unsubscribe = webhookService.subscribeToUserEvents(user.id, (event) => {
      // Global notifications logic
      switch (event.type) {
        case 'MESSAGE_RECEIVED':
          // Only show toast if it's an incoming message (not from user)
          if (!event.data.is_from_user) {
            toast({
              title: "New Message",
              description: (
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  <span className="truncate max-w-[200px]">{event.data.content}</span>
                </div>
              ),
            });
          }
          break;

        case 'CONTACT_UPDATED':
          // Optional: Toast for contact updates if critical
           // console.log('Contact updated:', event.data);
          break;

        default:
          break;
      }
    });

    return () => {
      unsubscribe();
    };
  }, [user, toast]);

  return null; // Invisible component
};

export default WebhookListener;