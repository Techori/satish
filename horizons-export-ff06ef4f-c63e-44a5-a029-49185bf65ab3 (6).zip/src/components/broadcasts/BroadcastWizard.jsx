
import React, { useState, useRef, useMemo } from 'react';
import { 
  ArrowRight, Upload, Users, CheckCircle2, AlertCircle, Play
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

const STEP_DETAILS = 1;
const STEP_TEMPLATE = 2;
const STEP_PREVIEW = 3;
const STEP_SENDING = 4;

const BroadcastWizard = ({ open, onOpenChange, templates, onComplete }) => {
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  
  const [step, setStep] = useState(STEP_DETAILS);
  const [data, setData] = useState({
    name: '',
    audienceType: 'all', // 'all', 'csv', 'tag'
    selectedTag: '',
    csvFile: null,
    recipients: [], // Array of { name, number }
    selectedTemplate: null,
    templateVariables: {},
  });
  
  const [sendingProgress, setSendingProgress] = useState(0);
  const [csvStats, setCsvStats] = useState({ valid: 0, invalid: 0 });

  const resetForm = () => {
    setStep(STEP_DETAILS);
    setData({
      name: '',
      audienceType: 'all',
      selectedTag: '',
      csvFile: null,
      recipients: [],
      selectedTemplate: null,
      templateVariables: {},
    });
    setSendingProgress(0);
  };

  const parseCSV = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      try {
        const rows = text.split(/\r?\n/).map(row => row.trim()).filter(row => row);
        if (rows.length < 2) throw new Error("File is empty or missing headers");

        const headers = rows[0].split(',').map(h => h.trim().toLowerCase().replace(/['"]+/g, ''));
        const nameIdx = headers.indexOf('name');
        const numberIdx = headers.indexOf('number') > -1 ? headers.indexOf('number') : headers.indexOf('phone');

        if (numberIdx === -1) throw new Error("Missing 'number' or 'phone' column");

        const validRecipients = [];
        let invalidCount = 0;

        rows.slice(1).forEach(row => {
          const cols = row.split(','); 
          const rawNumber = cols[numberIdx]?.replace(/\D/g, '');
          const name = nameIdx > -1 ? cols[nameIdx] : 'Valued Customer';

          if (rawNumber && rawNumber.startsWith('91') && rawNumber.length === 12) {
            validRecipients.push({ name: name?.trim() || 'Customer', number: rawNumber });
          } else {
            invalidCount++;
          }
        });

        if (validRecipients.length === 0) throw new Error("No valid Indian (91) numbers found.");

        setData(prev => ({ ...prev, recipients: validRecipients, csvFile: file }));
        setCsvStats({ valid: validRecipients.length, invalid: invalidCount });
        toast({ title: "CSV Parsed", description: `Found ${validRecipients.length} valid contacts. ${invalidCount} invalid/skipped.` });

      } catch (error) {
        toast({ title: "CSV Error", description: error.message, variant: "destructive" });
        setData(prev => ({ ...prev, csvFile: null, recipients: [] }));
      }
    };
    reader.readAsText(file);
  };

  const handleTemplateSelect = (template) => {
    const regex = /\{\{(\d+)\}\}/g;
    const vars = {};
    let match;
    while ((match = regex.exec(template.body)) !== null) {
        vars[match[1]] = '';
    }
    setData(prev => ({ ...prev, selectedTemplate: template, templateVariables: vars }));
  };

  const previewMessage = useMemo(() => {
    if (!data.selectedTemplate) return '';
    let msg = data.selectedTemplate.body;
    Object.entries(data.templateVariables).forEach(([key, val]) => {
        msg = msg.replace(`{{${key}}}`, val || `{{${key}}}`);
    });
    return msg;
  }, [data.selectedTemplate, data.templateVariables]);

  const handleNext = () => {
    if (step === STEP_DETAILS) {
        if (!data.name) return toast({ title: "Name required", variant: "destructive" });
        if (data.audienceType === 'csv' && data.recipients.length === 0) return toast({ title: "CSV required", variant: "destructive" });
    }
    if (step === STEP_TEMPLATE) {
        if (!data.selectedTemplate) return toast({ title: "Template required", variant: "destructive" });
    }
    setStep(prev => prev + 1);
  };

  const handleSend = async () => {
    setStep(STEP_SENDING);
    await onComplete(data, setSendingProgress);
    onOpenChange(false);
    resetForm();
  };

  return (
    <Dialog open={open} onOpenChange={(val) => { if(!val && step === STEP_SENDING) return; onOpenChange(val); if(!val) resetForm(); }}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>
             {step === STEP_SENDING ? "Sending Broadcast..." : "Create Broadcast Campaign"}
          </DialogTitle>
          <DialogDescription>
            {step === STEP_DETAILS && "Step 1: Audience & Details"}
            {step === STEP_TEMPLATE && "Step 2: Select Message Template"}
            {step === STEP_PREVIEW && "Step 3: Review & Send"}
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 min-h-[300px]">
          <AnimatePresence mode="wait">
            {step === STEP_DETAILS && (
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                    <div className="space-y-2">
                        <Label>Campaign Name</Label>
                        <Input 
                            placeholder="e.g. Diwali Promo 2024" 
                            value={data.name} 
                            onChange={e => setData(p => ({ ...p, name: e.target.value }))} 
                        />
                    </div>

                    <div className="space-y-3">
                        <Label>Select Audience</Label>
                        <Tabs value={data.audienceType} onValueChange={v => setData(p => ({ ...p, audienceType: v }))} className="w-full">
                            <TabsList className="grid w-full grid-cols-2">
                                <TabsTrigger value="all">Existing Contacts</TabsTrigger>
                                <TabsTrigger value="csv">Upload CSV</TabsTrigger>
                            </TabsList>
                            
                            <TabsContent value="all" className="pt-4 space-y-4">
                                <div className="p-4 bg-blue-50 rounded-lg flex items-center gap-3 text-blue-700">
                                    <Users className="w-5 h-5" />
                                    <div>
                                        <p className="font-medium">All Database Contacts</p>
                                        <p className="text-xs opacity-80">This will send to all valid contacts in your database.</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Label className="w-20">Filter Tag:</Label>
                                    <Select value={data.selectedTag} onValueChange={v => setData(p => ({...p, selectedTag: v}))}>
                                        <SelectTrigger className="w-full">
                                            <SelectValue placeholder="Optional: Select a tag filter" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="vip">VIP Customers</SelectItem>
                                            <SelectItem value="new">New Leads</SelectItem>
                                            <SelectItem value="inactive">Inactive</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </TabsContent>

                            <TabsContent value="csv" className="pt-4 space-y-4">
                                <div 
                                    onClick={() => fileInputRef.current?.click()}
                                    className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:bg-gray-50 cursor-pointer transition-colors"
                                >
                                    <input ref={fileInputRef} type="file" accept=".csv" className="hidden" onChange={e => parseCSV(e.target.files[0])} />
                                    <Upload className="w-8 h-8 mx-auto text-gray-400 mb-2" />
                                    <p className="text-sm font-medium text-gray-700">
                                        {data.csvFile ? data.csvFile.name : "Click to upload CSV"}
                                    </p>
                                    <p className="text-xs text-gray-500 mt-1">Headers: name, number (must start with 91)</p>
                                </div>
                                {data.recipients.length > 0 && (
                                    <div className="flex gap-4 text-xs">
                                        <span className="text-green-600 font-medium flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/> {csvStats.valid} valid</span>
                                        <span className="text-red-500 flex items-center gap-1"><AlertCircle className="w-3 h-3"/> {csvStats.invalid} invalid</span>
                                    </div>
                                )}
                            </TabsContent>
                        </Tabs>
                    </div>
                </motion.div>
            )}

            {step === STEP_TEMPLATE && (
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="h-full flex flex-col gap-4">
                    <div className="grid grid-cols-2 gap-4 h-[300px]">
                        <ScrollArea className="border rounded-lg p-2">
                            <div className="space-y-2">
                                {templates.map(t => (
                                    <div 
                                        key={t.id} 
                                        onClick={() => handleTemplateSelect(t)}
                                        className={cn(
                                            "p-3 rounded border cursor-pointer hover:bg-gray-50 transition-colors text-left",
                                            data.selectedTemplate?.id === t.id && "border-green-500 bg-green-50 ring-1 ring-green-500"
                                        )}
                                    >
                                        <p className="font-medium text-sm">{t.name}</p>
                                        <p className="text-xs text-gray-500 truncate">{t.body}</p>
                                    </div>
                                ))}
                            </div>
                        </ScrollArea>
                        <div className="space-y-4">
                            <div className="bg-gray-100 rounded-lg p-4 h-40 overflow-y-auto">
                                <Label className="text-xs text-gray-500 mb-1 block">Preview</Label>
                                <p className="text-sm whitespace-pre-wrap">{previewMessage || "Select a template..."}</p>
                            </div>
                            <div className="space-y-2">
                                {Object.keys(data.templateVariables).map(key => (
                                    <div key={key}>
                                        <Label className="text-xs">Variable {'{{' + key + '}}'}</Label>
                                        <Input 
                                            className="h-8 text-sm" 
                                            value={data.templateVariables[key]}
                                            onChange={e => setData(p => ({ 
                                                ...p, 
                                                templateVariables: { ...p.templateVariables, [key]: e.target.value }
                                            }))}
                                        />
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </motion.div>
            )}

            {step === STEP_PREVIEW && (
                 <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                    <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                        <h3 className="font-semibold text-green-900 mb-2">Summary</h3>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                                <p className="text-green-700 opacity-70">Audience</p>
                                <p className="font-medium">{data.audienceType === 'csv' ? `CSV Import (${data.recipients.length} contacts)` : 'Database Contacts'}</p>
                            </div>
                            <div>
                                <p className="text-green-700 opacity-70">Template</p>
                                <p className="font-medium">{data.selectedTemplate?.name}</p>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <Label className="mb-2 block">Message Preview</Label>
                        <div className="p-4 bg-white border rounded-lg shadow-sm">
                            <p className="whitespace-pre-wrap text-sm text-gray-800">{previewMessage}</p>
                        </div>
                    </div>
                    
                    <div className="flex items-center gap-2 text-xs text-yellow-600 bg-yellow-50 p-2 rounded">
                        <AlertCircle className="w-4 h-4" />
                        <span>Messages will be sent in batches to ensure API compliance. Do not close the window until started.</span>
                    </div>
                 </motion.div>
            )}
            
            {step === STEP_SENDING && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-10">
                    <div className="relative w-24 h-24 mx-auto mb-6">
                        <div className="absolute inset-0 rounded-full border-4 border-gray-100"></div>
                        <div className="absolute inset-0 rounded-full border-4 border-green-500 border-t-transparent animate-spin"></div>
                        <div className="absolute inset-0 flex items-center justify-center">
                           <span className="text-lg font-bold text-green-600">{Math.round(sendingProgress)}%</span>
                        </div>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Broadcasting Messages</h3>
                    <p className="text-gray-500 max-w-xs mx-auto">
                        Processing batch delivery. Please verify delivery status in the analytics dashboard after completion.
                    </p>
                </motion.div>
            )}

          </AnimatePresence>
        </div>

        <DialogFooter>
            {step !== STEP_SENDING && (
                <>
                    <Button variant="outline" onClick={() => step === 1 ? onOpenChange(false) : setStep(p => p - 1)}>
                        {step === 1 ? 'Cancel' : 'Back'}
                    </Button>
                    {step < STEP_PREVIEW ? (
                        <Button onClick={handleNext} className="whatsapp-gradient">Next <ArrowRight className="w-4 h-4 ml-2" /></Button>
                    ) : (
                        <Button onClick={handleSend} className="whatsapp-gradient px-8">
                            <Play className="w-4 h-4 mr-2" /> Start Broadcast
                        </Button>
                    )}
                </>
            )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BroadcastWizard;
