
import React, { useState, useEffect, useMemo } from 'react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend,
  BarChart, Bar, XAxis, YAxis, CartesianGrid
} from 'recharts';
import { 
  Loader2, RefreshCw, CheckCircle2, XCircle, Search, Filter,
  Download, Clock, ArrowUpRight, CheckCheck, Send, AlertTriangle
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/lib/customSupabaseClient';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const COLORS = {
  sent: '#3b82f6', // blue
  delivered: '#22c55e', // green
  read: '#a855f7', // purple
  failed: '#ef4444', // red
  pending: '#9ca3af' // gray
};

const STATUS_ICONS = {
  sent: <Send className="w-4 h-4 text-blue-500" />,
  delivered: <CheckCircle2 className="w-4 h-4 text-green-500" />,
  read: <CheckCheck className="w-4 h-4 text-purple-500" />,
  failed: <XCircle className="w-4 h-4 text-red-500" />,
  pending: <Clock className="w-4 h-4 text-gray-400" />
};

const BroadcastAnalytics = ({ open, onOpenChange, broadcast }) => {
  const { toast } = useToast();
  const [recipients, setRecipients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [retrying, setRetrying] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [refreshInterval, setRefreshInterval] = useState(null);
  const [isAutoRefreshing, setIsAutoRefreshing] = useState(true);

  const fetchRecipients = async (isBackground = false) => {
    if (!broadcast) return;
    if (!isBackground) setLoading(true);
    
    const { data, error } = await supabase
      .from('broadcast_recipients')
      .select('*')
      .eq('broadcast_id', broadcast.id)
      .order('updated_at', { ascending: false });

    if (error) {
      console.error('Error fetching recipients:', error);
      if (!isBackground) toast({ title: 'Error', description: 'Failed to load broadcast data', variant: 'destructive' });
    } else {
      setRecipients(data);
    }
    if (!isBackground) setLoading(false);
  };

  useEffect(() => {
    if (open && broadcast) {
      fetchRecipients();
      // Auto-refresh every 3 seconds if the broadcast is recent or still processing
      if (isAutoRefreshing) {
        const interval = setInterval(() => fetchRecipients(true), 3000);
        setRefreshInterval(interval);
        return () => clearInterval(interval);
      }
    }
    return () => {
        if (refreshInterval) clearInterval(refreshInterval);
    };
  }, [open, broadcast, isAutoRefreshing]);

  const stats = useMemo(() => {
    const initial = { sent: 0, delivered: 0, read: 0, failed: 0, pending: 0, total: 0 };
    return recipients.reduce((acc, curr) => {
      const status = curr.status?.toLowerCase() || 'pending';
      acc.total++;
      if (status === 'read') acc.read++;
      else if (status === 'delivered') acc.delivered++;
      else if (status === 'failed') acc.failed++;
      else if (status === 'sent') acc.sent++;
      else acc.pending++;
      return acc;
    }, initial);
  }, [recipients]);

  const chartData = useMemo(() => [
    { name: 'Read', value: stats.read, color: COLORS.read },
    { name: 'Delivered', value: stats.delivered, color: COLORS.delivered },
    { name: 'Sent', value: stats.sent, color: COLORS.sent },
    { name: 'Failed', value: stats.failed, color: COLORS.failed },
    { name: 'Pending', value: stats.pending, color: COLORS.pending },
  ].filter(d => d.value > 0), [stats]);

  const filteredRecipients = useMemo(() => {
    return recipients.filter(r => {
      const matchesSearch = (r.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           r.phone_number?.includes(searchTerm));
      const matchesFilter = statusFilter === 'all' || r.status === statusFilter;
      return matchesSearch && matchesFilter;
    });
  }, [recipients, searchTerm, statusFilter]);

  const progressPercentage = useMemo(() => {
     if (stats.total === 0) return 0;
     const completed = stats.read + stats.delivered + stats.failed + stats.sent; // Sent counts as processed by API
     return Math.round((completed / stats.total) * 100);
  }, [stats]);

  const handleRetryFailed = async () => {
    setRetrying(true);
    const failedIds = recipients.filter(r => r.status === 'failed').map(r => r.id);
    
    try {
      await supabase
        .from('broadcast_recipients')
        .update({ status: 'pending', error_message: null })
        .in('id', failedIds);

      toast({ title: "Retry Initiated", description: `Queued ${failedIds.length} messages for retry.` });
      
      // Simulated retry process for demonstration
      setTimeout(async () => {
        const updates = failedIds.map(id => ({
            id,
            status: Math.random() > 0.2 ? 'sent' : 'failed',
            error_message: Math.random() > 0.2 ? null : 'Retry failed: Network timeout'
        }));
        
        for (const update of updates) {
            await supabase.from('broadcast_recipients').update({ status: update.status, error_message: update.error_message }).eq('id', update.id);
        }
        
        fetchRecipients();
        setRetrying(false);
        toast({ title: "Retry Complete", description: "Failed messages have been reprocessed." });
      }, 2000);

    } catch (error) {
      setRetrying(false);
      toast({ title: "Retry Failed", variant: "destructive" });
    }
  };

  const exportReport = () => {
    const headers = ["Name", "Phone Number", "Status", "Updated At", "Error Message"];
    const csvContent = [
      headers.join(","),
      ...recipients.map(r => [
        `"${r.name || ''}"`,
        `"${r.phone_number}"`,
        r.status,
        new Date(r.updated_at).toLocaleString(),
        `"${r.error_message || ''}"`
      ].join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `broadcast_report_${broadcast.name}_${new Date().toISOString()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({ title: "Export Started", description: "Your report is downloading." });
  };

  if (!broadcast) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl w-full h-[95vh] flex flex-col p-0 gap-0 bg-gray-50/95 backdrop-blur-sm">
        <DialogHeader className="p-6 border-b bg-white sticky top-0 z-20">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <div className="flex items-center gap-3">
                  <DialogTitle className="text-2xl font-bold text-gray-900">{broadcast.name}</DialogTitle>
                  <Badge variant={broadcast.status === 'Processing' ? 'secondary' : 'outline'} className="uppercase tracking-wider font-semibold">
                    {broadcast.status}
                  </Badge>
              </div>
              <DialogDescription className="mt-1 flex items-center gap-2 text-gray-500">
                <span>Template: <span className="font-medium text-gray-700">{broadcast.template_name}</span></span>
                <span>•</span>
                <span>Created: {new Date(broadcast.created_at).toLocaleString()}</span>
              </DialogDescription>
            </div>
            <div className="flex items-center gap-2">
               <div className="flex items-center gap-2 mr-4 bg-gray-100 rounded-full px-3 py-1">
                  <div className={cn("w-2 h-2 rounded-full", isAutoRefreshing ? "bg-green-500 animate-pulse" : "bg-gray-400")} />
                  <span className="text-xs font-medium text-gray-600">{isAutoRefreshing ? "Live Updates On" : "Live Updates Off"}</span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-5 w-5 ml-1 hover:bg-white rounded-full" 
                    onClick={() => setIsAutoRefreshing(!isAutoRefreshing)}
                  >
                    {isAutoRefreshing ? <XCircle className="w-3 h-3" /> : <RefreshCw className="w-3 h-3" />}
                  </Button>
               </div>
               <Button variant="outline" size="sm" onClick={exportReport}>
                  <Download className="w-4 h-4 mr-2" />
                  Export Report
               </Button>
            </div>
          </div>
          
          <div className="mt-6 space-y-2">
            <div className="flex justify-between text-sm font-medium text-gray-600">
                <span>Campaign Progress</span>
                <span>{progressPercentage}% ({stats.total - stats.pending}/{stats.total})</span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex flex-col">
          <Tabs defaultValue="dashboard" className="h-full flex flex-col">
            <div className="px-6 pt-4 bg-white border-b">
              <TabsList className="w-full sm:w-auto grid grid-cols-2 sm:flex">
                <TabsTrigger value="dashboard" className="px-6">Live Dashboard</TabsTrigger>
                <TabsTrigger value="details" className="px-6">Message Log</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="dashboard" className="flex-1 overflow-y-auto p-6 space-y-6 m-0">
              {/* KPI Cards */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <Card className="bg-white border-l-4 border-l-gray-400 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                        <div className="text-xs font-medium text-gray-500 uppercase">Total</div>
                        <div className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</div>
                    </CardContent>
                </Card>
                <Card className="bg-white border-l-4 border-l-blue-500 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                        <div className="text-xs font-medium text-blue-600 uppercase">Sent</div>
                        <div className="text-2xl font-bold text-blue-700 mt-1">{stats.sent}</div>
                    </CardContent>
                </Card>
                <Card className="bg-white border-l-4 border-l-green-500 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                        <div className="text-xs font-medium text-green-600 uppercase">Delivered</div>
                        <div className="text-2xl font-bold text-green-700 mt-1">{stats.delivered}</div>
                    </CardContent>
                </Card>
                <Card className="bg-white border-l-4 border-l-purple-500 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                        <div className="text-xs font-medium text-purple-600 uppercase">Read</div>
                        <div className="text-2xl font-bold text-purple-700 mt-1">{stats.read}</div>
                    </CardContent>
                </Card>
                <Card className="bg-white border-l-4 border-l-red-500 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                        <div className="text-xs font-medium text-red-600 uppercase">Failed</div>
                        <div className="text-2xl font-bold text-red-700 mt-1">{stats.failed}</div>
                    </CardContent>
                </Card>
              </div>

              {/* Charts Row */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[400px]">
                <Card className="shadow-sm">
                  <CardHeader><CardTitle>Delivery Overview</CardTitle></CardHeader>
                  <CardContent className="h-[300px]">
                    {chartData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                            data={chartData}
                            cx="50%"
                            cy="50%"
                            innerRadius={80}
                            outerRadius={110}
                            paddingAngle={2}
                            dataKey="value"
                            >
                            {chartData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                            ))}
                            </Pie>
                            <RechartsTooltip 
                                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                            />
                            <Legend verticalAlign="bottom" height={36} iconType="circle" />
                        </PieChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="h-full flex items-center justify-center text-gray-400">Waiting for data...</div>
                    )}
                  </CardContent>
                </Card>

                <Card className="shadow-sm flex flex-col">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle>Failed Deliveries</CardTitle>
                        {stats.failed > 0 && (
                            <Button size="sm" variant="destructive" onClick={handleRetryFailed} disabled={retrying}>
                                {retrying ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <RefreshCw className="w-3 h-3 mr-2" />}
                                Retry All ({stats.failed})
                            </Button>
                        )}
                    </CardHeader>
                    <CardContent className="flex-1 overflow-hidden">
                         <ScrollArea className="h-[300px] pr-4">
                            {stats.failed === 0 ? (
                                <div className="h-full flex flex-col items-center justify-center text-green-600 bg-green-50 rounded-lg border border-dashed border-green-200 m-2">
                                    <CheckCircle2 className="w-12 h-12 mb-3 opacity-50" />
                                    <p className="font-medium">No delivery failures</p>
                                    <p className="text-xs text-green-600/70 mt-1">All processed messages were sent successfully</p>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    {recipients.filter(r => r.status === 'failed').map((fail, i) => (
                                        <div key={i} className="flex items-start justify-between p-3 bg-red-50 rounded-lg border border-red-100 text-sm group hover:bg-red-100 transition-colors">
                                            <div className="flex items-start gap-3">
                                                <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
                                                <div>
                                                    <p className="font-semibold text-gray-900">{fail.name || 'Unknown Contact'}</p>
                                                    <p className="text-gray-600 font-mono text-xs mt-0.5">{fail.phone_number}</p>
                                                </div>
                                            </div>
                                            <div className="text-right max-w-[150px]">
                                                 <p className="text-red-600 text-xs font-medium break-words">{fail.error_message || "Unknown API Error"}</p>
                                                 <p className="text-gray-400 text-[10px] mt-1">{new Date(fail.updated_at).toLocaleTimeString()}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                         </ScrollArea>
                    </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="details" className="flex-1 overflow-hidden flex flex-col m-0 bg-white">
               {/* Filter Bar */}
               <div className="p-4 border-b flex flex-col sm:flex-row gap-4 items-center bg-gray-50/50">
                  <div className="relative w-full sm:w-72">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                    <Input
                      placeholder="Search name or number..."
                      className="pl-9 bg-white"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <Filter className="w-4 h-4 text-gray-500" />
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-[180px] bg-white">
                        <SelectValue placeholder="Filter Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Statuses</SelectItem>
                        <SelectItem value="sent">Sent</SelectItem>
                        <SelectItem value="delivered">Delivered</SelectItem>
                        <SelectItem value="read">Read</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="ml-auto text-sm text-gray-500">
                    Showing {filteredRecipients.length} of {recipients.length}
                  </div>
               </div>

               {/* Table */}
               <div className="flex-1 overflow-auto">
                   <table className="w-full text-sm text-left">
                       <thead className="bg-gray-50 sticky top-0 z-10 text-xs uppercase text-gray-500 font-semibold shadow-sm">
                           <tr>
                               <th className="px-6 py-4 w-16">#</th>
                               <th className="px-6 py-4">Recipient</th>
                               <th className="px-6 py-4">Status</th>
                               <th className="px-6 py-4">Last Update</th>
                               <th className="px-6 py-4">Message Info</th>
                           </tr>
                       </thead>
                       <tbody className="divide-y divide-gray-100 bg-white">
                           {filteredRecipients.length > 0 ? (
                               filteredRecipients.map((row, idx) => (
                                   <tr key={row.id} className="hover:bg-blue-50/30 transition-colors group">
                                       <td className="px-6 py-4 text-gray-400">{idx + 1}</td>
                                       <td className="px-6 py-4">
                                           <div className="font-medium text-gray-900">{row.name || 'Unknown Contact'}</div>
                                           <div className="text-xs text-gray-500 font-mono mt-0.5">{row.phone_number}</div>
                                       </td>
                                       <td className="px-6 py-4">
                                           <Badge 
                                              variant="outline" 
                                              className={cn(
                                                "capitalize pl-2 pr-3 py-1 flex w-fit items-center gap-2 font-normal transition-all",
                                                row.status === 'read' && "bg-purple-50 text-purple-700 border-purple-200",
                                                row.status === 'delivered' && "bg-green-50 text-green-700 border-green-200",
                                                row.status === 'sent' && "bg-blue-50 text-blue-700 border-blue-200",
                                                row.status === 'failed' && "bg-red-50 text-red-700 border-red-200",
                                                (!row.status || row.status === 'pending') && "bg-gray-50 text-gray-600 border-gray-200"
                                              )}
                                           >
                                               {STATUS_ICONS[row.status?.toLowerCase()] || STATUS_ICONS.pending}
                                               {row.status || 'Pending'}
                                           </Badge>
                                       </td>
                                       <td className="px-6 py-4 text-gray-500 font-mono text-xs">
                                           {row.updated_at ? new Date(row.updated_at).toLocaleTimeString() : '-'}
                                       </td>
                                       <td className="px-6 py-4">
                                           {row.error_message ? (
                                              <span className="text-red-600 flex items-center gap-1 text-xs font-medium bg-red-50 px-2 py-1 rounded max-w-xs truncate">
                                                <AlertTriangle className="w-3 h-3" />
                                                {row.error_message}
                                              </span>
                                           ) : (
                                              <span className="text-gray-400 text-xs italic">No issues</span>
                                           )}
                                       </td>
                                   </tr>
                               ))
                           ) : (
                               <tr>
                                 <td colSpan={5} className="h-32 text-center">
                                    <div className="flex flex-col items-center justify-center text-gray-400">
                                      <Search className="w-8 h-8 mb-2 opacity-20" />
                                      <p>No recipients found matching your filters.</p>
                                    </div>
                                 </td>
                               </tr>
                           )}
                       </tbody>
                   </table>
               </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BroadcastAnalytics;
