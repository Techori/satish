
import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Download, 
  X, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  AlertTriangle 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { cn } from '@/lib/utils';

const STEP_UPLOAD = 'upload';
const STEP_PREVIEW = 'preview';
const STEP_IMPORTING = 'importing';
const STEP_RESULTS = 'results';

const ImportContactsDialog = ({ open, onOpenChange, onImportSuccess }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  
  const [step, setStep] = useState(STEP_UPLOAD);
  const [file, setFile] = useState(null);
  const [parsedContacts, setParsedContacts] = useState([]);
  const [validationStats, setValidationStats] = useState({ valid: 0, invalid: 0 });
  const [importStats, setImportStats] = useState({ success: 0, duplicates: 0, failed: 0 });
  const [progress, setProgress] = useState(0);
  const [errors, setErrors] = useState([]);

  // Reset state when dialog opens/closes
  useEffect(() => {
    if (!open) {
      setTimeout(() => {
        setStep(STEP_UPLOAD);
        setFile(null);
        setParsedContacts([]);
        setErrors([]);
        setProgress(0);
      }, 300);
    }
  }, [open]);

  const handleDownloadTemplate = () => {
    // Updated template with Indian number format example
    const csvContent = "data:text/csv;charset=utf-8,name,number\nJohn Doe,919876543210\nJane Smith,919876543211";
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "contacts_template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (selectedFile.type !== 'text/csv' && !selectedFile.name.endsWith('.csv')) {
        toast({ title: "Invalid file type", description: "Please upload a CSV file.", variant: "destructive" });
        return;
      }
      setFile(selectedFile);
      parseFile(selectedFile);
    }
  };

  // Robust CSV line parser that handles commas inside quotes
  const parseCSVLine = (text) => {
    const result = [];
    let cell = '';
    let inQuotes = false;
    
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(cell.trim());
        cell = '';
      } else {
        cell += char;
      }
    }
    result.push(cell.trim());
    return result.map(c => c.replace(/^"|"$/g, '').replace(/""/g, '"'));
  };

  const parseFile = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      try {
        const rows = text.split(/\r?\n/).map(row => row.trim()).filter(row => row);
        if (rows.length < 2) throw new Error("File is empty or missing headers");

        const headers = rows[0].split(',').map(h => h.trim().toLowerCase().replace(/['"]+/g, ''));
        const nameIdx = headers.indexOf('name');
        const numberIdx = headers.indexOf('number');

        if (nameIdx === -1 || numberIdx === -1) {
          throw new Error("Missing required columns: 'name' and 'number'");
        }

        const contacts = [];
        let validCount = 0;
        let invalidCount = 0;
        const parseErrors = [];

        rows.slice(1).forEach((row, index) => {
          const rowNum = index + 2;
          try {
            const cols = parseCSVLine(row);
            
            // Handle potential mismatch in column length vs headers
            if (cols.length < 2) {
               parseErrors.push(`Row ${rowNum}: Malformed row`);
               invalidCount++;
               return;
            }

            const name = cols[nameIdx];
            const rawNumber = cols[numberIdx];

            // 1. Require name field to be non-empty
            if (!name || name.trim() === '') {
              parseErrors.push(`Row ${rowNum}: Name is required`);
              invalidCount++;
              return;
            }

            // 2. Validate phone number
            if (!rawNumber) {
              parseErrors.push(`Row ${rowNum}: Number is required`);
              invalidCount++;
              return;
            }

            // Strip non-digits
            const cleanNumber = rawNumber.replace(/\D/g, '');

            // 3. Mandate that phone numbers must start with 91 (Indian numbers only)
            // Check length: 91 + 10 digits = 12 digits total
            if (!cleanNumber.startsWith('91')) {
              parseErrors.push(`Row ${rowNum}: Number '${rawNumber}' must start with country code 91`);
              invalidCount++;
              return;
            }

            if (cleanNumber.length !== 12) {
              parseErrors.push(`Row ${rowNum}: Invalid length for '${rawNumber}'. Expected 12 digits (91 + 10 digit mobile).`);
              invalidCount++;
              return;
            }

            contacts.push({ name: name.trim(), number: cleanNumber, status: 'pending' });
            validCount++;

          } catch (err) {
            invalidCount++;
            parseErrors.push(`Row ${rowNum}: Parsing error`);
          }
        });

        setParsedContacts(contacts);
        setValidationStats({ valid: validCount, invalid: invalidCount });
        setErrors(parseErrors);
        setStep(STEP_PREVIEW);

      } catch (error) {
        toast({ title: "Parsing Error", description: error.message, variant: "destructive" });
        setFile(null);
      }
    };
    reader.readAsText(file);
  };

  const handleImport = async () => {
    setStep(STEP_IMPORTING);
    setProgress(10);

    try {
      const contactsToProcess = parsedContacts;
      if (contactsToProcess.length === 0) {
        throw new Error("No valid contacts to import");
      }

      const numbersToCheck = contactsToProcess.map(c => c.number);
      
      // 1. Check for duplicates in DB
      // Batch check 
      const { data: existingContacts, error: fetchError } = await supabase
        .from('contacts')
        .select('number')
        .eq('user_id', user.id)
        .in('number', numbersToCheck);

      if (fetchError) throw fetchError;

      setProgress(30);

      const existingNumbers = new Set(existingContacts.map(c => c.number));
      const newContacts = [];
      let duplicates = 0;

      contactsToProcess.forEach(contact => {
        if (existingNumbers.has(contact.number)) {
          duplicates++;
        } else {
          newContacts.push({
            user_id: user.id,
            name: contact.name,
            number: contact.number,
            created_at: new Date().toISOString()
          });
        }
      });

      setProgress(50);

      // 2. Insert new contacts
      let success = 0;
      let failed = 0;

      if (newContacts.length > 0) {
        // Supabase limits batch size, safer to chunk if large
        const CHUNK_SIZE = 100;
        const chunks = [];
        for (let i = 0; i < newContacts.length; i += CHUNK_SIZE) {
          chunks.push(newContacts.slice(i, i + CHUNK_SIZE));
        }

        const chunkProgressStep = 40 / (chunks.length || 1);
        let currentProgress = 50;

        for (const chunk of chunks) {
          const { error: insertError } = await supabase
            .from('contacts')
            .insert(chunk);

          if (insertError) {
            console.error("Batch insert error:", insertError);
            failed += chunk.length;
            toast({ 
              title: "Batch Insert Failed", 
              description: "A batch of contacts failed to save. Please check your data.", 
              variant: "destructive" 
            });
          } else {
            success += chunk.length;
          }
          currentProgress += chunkProgressStep;
          setProgress(currentProgress);
        }
      }

      setProgress(100);
      setImportStats({ success, duplicates, failed });
      setStep(STEP_RESULTS);
      
      if (success > 0) {
        onImportSuccess?.();
      }

    } catch (error) {
      console.error("Import failed:", error);
      toast({ title: "Import Failed", description: error.message, variant: "destructive" });
      setStep(STEP_PREVIEW); // Go back to allow retry
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] glass-effect">
        <DialogHeader>
          <DialogTitle>Import Contacts</DialogTitle>
          <DialogDescription>
            Add contacts in bulk by uploading a CSV file. Numbers must include the country code 91.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {step === STEP_UPLOAD && (
            <div className="space-y-4">
              <div
                className="group relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-gray-300 bg-gray-50/50 px-6 py-10 text-center transition-all hover:border-green-500 hover:bg-green-50/30 cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={handleFileSelect}
                />
                <div className="p-4 rounded-full bg-green-100 mb-4 group-hover:scale-110 transition-transform">
                  <Upload className="h-8 w-8 text-green-600" />
                </div>
                <p className="text-sm font-medium text-gray-700">
                  Click to upload or drag and drop
                </p>
                <p className="text-xs text-gray-500 mt-1">CSV file (max 10MB)</p>
              </div>

              <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border border-blue-100">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm font-medium text-blue-900">Need a template?</p>
                    <p className="text-xs text-blue-700">Download our sample CSV file</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={handleDownloadTemplate} className="bg-white border-blue-200 text-blue-700 hover:bg-blue-50">
                  <Download className="w-4 h-4 mr-2" /> Download
                </Button>
              </div>
              
               <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100 flex gap-3 items-start">
                <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 shrink-0" />
                <div className="text-xs text-yellow-700">
                  <p className="font-semibold mb-1">Requirements:</p>
                  <ul className="list-disc pl-4 space-y-1">
                    <li>Phone numbers must start with <span className="font-mono font-bold">91</span> (India).</li>
                    <li>Phone numbers must be 12 digits total (91 + 10 digits).</li>
                    <li>Name field is required.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {step === STEP_PREVIEW && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">{file?.name}</p>
                    <p className="text-xs text-gray-500">{(file?.size / 1024).toFixed(1)} KB</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setStep(STEP_UPLOAD)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-green-50 rounded-lg border border-green-100 text-center">
                  <p className="text-2xl font-bold text-green-700">{validationStats.valid}</p>
                  <p className="text-xs text-green-600 font-medium">Valid Contacts</p>
                </div>
                <div className="p-3 bg-red-50 rounded-lg border border-red-100 text-center">
                  <p className="text-2xl font-bold text-red-700">{validationStats.invalid}</p>
                  <p className="text-xs text-red-600 font-medium">Invalid Rows</p>
                </div>
              </div>

              {errors.length > 0 && (
                <ScrollArea className="h-[150px] rounded-md border p-3 bg-red-50/50">
                  <div className="space-y-2">
                    {errors.map((err, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-red-600">
                        <AlertCircle className="w-3 h-3 mt-0.5 shrink-0" />
                        <span className="font-medium">{err}</span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}

              {validationStats.valid > 0 && (
                 <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 flex gap-3 items-start">
                  <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <p className="text-xs text-blue-700">
                    Valid contacts will be checked for duplicates against your existing list before importing.
                  </p>
                </div>
              )}
            </div>
          )}

          {step === STEP_IMPORTING && (
            <div className="py-8 text-center space-y-6">
              <div className="relative w-20 h-20 mx-auto">
                <div className="absolute inset-0 rounded-full border-4 border-gray-100"></div>
                <div className="absolute inset-0 rounded-full border-4 border-green-500 border-t-transparent animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-bold text-green-600">{Math.round(progress)}%</span>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium text-gray-900">Importing Contacts...</h3>
                <p className="text-sm text-gray-500 mt-1">Please do not close this window.</p>
              </div>
              <div className="w-full max-w-xs mx-auto">
                <Progress value={progress} className="h-2" />
              </div>
            </div>
          )}

          {step === STEP_RESULTS && (
            <div className="space-y-6 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">Import Complete!</h3>
                <p className="text-gray-500">Your contacts have been processed successfully.</p>
              </div>

              <div className="grid grid-cols-3 gap-4 border-t border-b border-gray-100 py-4">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Added</p>
                  <p className="text-xl font-bold text-green-600">{importStats.success}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Duplicates</p>
                  <p className="text-xl font-bold text-yellow-600">{importStats.duplicates}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Failed</p>
                  <p className="text-xl font-bold text-red-600">{importStats.failed}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          {step === STEP_UPLOAD && (
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          )}
          {step === STEP_PREVIEW && (
            <>
              <Button variant="ghost" onClick={() => setStep(STEP_UPLOAD)}>Back</Button>
              <Button 
                onClick={handleImport} 
                disabled={validationStats.valid === 0}
                className="whatsapp-gradient text-white"
              >
                Import {validationStats.valid} Contacts
              </Button>
            </>
          )}
          {step === STEP_RESULTS && (
            <Button onClick={() => onOpenChange(false)} className="w-full whatsapp-gradient text-white">
              Done
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ImportContactsDialog;
