
import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Users, 
  Radio, 
  Bot, 
  FileText, 
  BarChart3, 
  UserCog, 
  Settings, 
  Menu, 
  X, 
  MessageCircle,
  User,
  LogOut,
  LifeBuoy
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Inbox', href: '/inbox', icon: MessageSquare },
  { name: 'Contacts', href: '/contacts', icon: Users },
  { name: 'Broadcasts', href: '/broadcasts', icon: Radio },
  { name: 'Chatbots', href: '/chatbots', icon: Bot },
  { name: 'Templates', href: '/templates', icon: FileText },
  { name: 'Analytics', href: '/analytics', icon: BarChart3 },
];

const bottomNav = [
  { name: 'Team', href: '/team', icon: UserCog },
  { name: 'Settings', href: '/settings', icon: Settings },
];

const Layout = ({ children }) => {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const pageTitle = 
    [...navigation, ...bottomNav].find(item => location.pathname.startsWith(item.href))?.name || 
    (location.pathname === '/profile' ? 'My Profile' : 'Dashboard');

  const SidebarContent = () => (
    <div className="flex flex-col h-full whatsapp-gradient text-white">
      <div className="flex items-center justify-between p-4 border-b border-white/20 h-16">
        <Link to="/dashboard" className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-white/30 backdrop-blur-sm rounded-lg flex items-center justify-center shadow-lg">
            <MessageCircle className="w-5 h-5 text-white" />
          </div>
          <span className="text-lg font-bold text-white">Wabista</span>
        </Link>
        <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-white hover:text-gray-100 p-1 rounded-md">
          <X className="w-6 h-6" />
        </button>
      </div>
      <div className="flex-1 flex flex-col justify-between overflow-y-auto">
        <nav className="p-3 space-y-2"> {/* Increased space-y for better mobile separation */}
          {navigation.map(item => {
            const isActive = location.pathname.startsWith(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center space-x-3 px-4 py-3.5 rounded-xl transition-all duration-200 text-base font-bold group", // Made font-bold and text-base for better visibility
                  isActive 
                    ? "bg-white/30 text-white shadow-md" 
                    : "text-white hover:bg-white/10"
                )}
              >
                <item.icon className={cn("w-5 h-5", "text-white")} />
                <span className="font-bold">{item.name}</span>
              </Link>
            );
          })}
        </nav>
        <nav className="p-3 space-y-2 border-t border-white/20"> {/* Increased space-y for better mobile separation */}
          {bottomNav.map(item => {
            const isActive = location.pathname.startsWith(item.href);
            return (
              <Link
                key={item.name}
                to={item.href}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center space-x-3 px-4 py-3.5 rounded-xl transition-all duration-200 text-base font-bold group", // Made font-bold and text-base for better visibility
                  isActive 
                    ? "bg-white/30 text-white shadow-md" 
                    : "text-white hover:bg-white/10"
                )}
              >
                <item.icon className={cn("w-5 h-5", "text-white")} />
                <span className="font-bold">{item.name}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Mobile sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed lg:hidden inset-y-0 left-0 z-50 w-64 shadow-2xl"
            >
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Desktop sidebar */}
      <aside className="hidden lg:flex lg:flex-shrink-0 w-64">
        <SidebarContent />
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="bg-white/80 backdrop-blur-lg border-b border-gray-200/80 sticky top-0 z-30 h-16 flex items-center">
          <div className="flex items-center justify-between px-4 sm:px-6 lg:px-8 w-full">
            <div className="flex items-center">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 -ml-2 text-gray-600">
                <Menu className="w-6 h-6" />
              </button>
              <h1 className="text-xl font-bold text-gray-800 ml-2 lg:ml-0">
                {pageTitle}
              </h1>
            </div>

            <div className="flex items-center space-x-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center space-x-3 p-1 rounded-full hover:bg-gray-100 transition-colors">
                    <Avatar className="w-9 h-9">
                      <AvatarImage src={user?.user_metadata?.avatar_url} />
                      <AvatarFallback className="bg-gradient-to-br from-green-500 to-emerald-600 text-white font-bold">
                        {user?.user_metadata?.full_name?.charAt(0).toUpperCase() || user?.email?.charAt(0).toUpperCase() || 'A'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="hidden md:block text-left">
                      <p className="text-sm font-medium text-gray-800 truncate">{user?.user_metadata?.full_name || user?.email}</p>
                      <p className="text-xs text-gray-500">Workspace Owner</p>
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end">
                  <DropdownMenuLabel>{user?.user_metadata?.full_name || user?.email}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <Link to="/profile">
                    <DropdownMenuItem>
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                  </Link>
                  <Link to="/settings">
                    <DropdownMenuItem>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuItem disabled>
                    <LifeBuoy className="mr-2 h-4 w-4" />
                    <span>Support</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="flex-1 overflow-auto">
          <div className="p-4 sm:p-6 lg:p-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
