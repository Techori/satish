import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Shield, 
  Key, 
  Webhook, 
  Server, 
  Lock,
  Users,
  AlertTriangle,
  Activity,
  FileClock,
  Gauge
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import AdminActivityLogs from '@/components/AdminActivityLogs';
import AdminApiMonitoring from '@/components/AdminApiMonitoring';
import AdminSystemHealth from '@/components/AdminSystemHealth';

const AdminControls = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [config, setConfig] = useState({
    whatsappToken: 'EAAG...',
    webhookUrl: 'https://api.whatsbiz.com/webhooks/whatsapp',
    webhookSecret: 'whsec_...',
    verifyToken: 'whatsbiz_verify_v1',
    apiRateLimit: '1000',
    maintenanceMode: false
  });

  // Enhanced User Role Data
  const [users, setUsers] = useState([
    { id: 1, name: 'John Admin', email: 'john@whatsbiz.com', role: 'super_admin', status: 'active', lastActive: '2 mins ago' },
    { id: 2, name: 'Sarah Support', email: 'sarah@whatsbiz.com', role: 'manager', status: 'active', lastActive: '1 hour ago' },
    { id: 3, name: 'Mike Dev', email: 'mike@whatsbiz.com', role: 'developer', status: 'inactive', lastActive: '2 days ago' },
    { id: 4, name: 'Emma Agent', email: 'emma@whatsbiz.com', role: 'agent', status: 'active', lastActive: '5 mins ago' },
    { id: 5, name: 'Guest View', email: 'guest@whatsbiz.com', role: 'viewer', status: 'active', lastActive: '1 day ago' },
  ]);

  const handleSaveConfig = async (section) => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "Configuration Saved",
        description: `${section} settings have been updated successfully.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save configuration.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = (userId, newRole) => {
    setUsers(users.map(user => 
      user.id === userId ? { ...user, role: newRole } : user
    ));
    toast({
      title: "Role Updated",
      description: "User permissions have been updated."
    });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setConfig(prev => ({ ...prev, [name]: value }));
  };

  // Helper to get role badge color
  const getRoleBadge = (role) => {
    switch(role) {
      case 'super_admin': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'manager': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'developer': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'agent': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-600 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Admin Controls</h2>
          <p className="text-gray-600">System-wide configuration and access management</p>
        </div>
        <div className="flex items-center gap-2 bg-yellow-50 px-4 py-2 rounded-lg border border-yellow-200">
          <Shield className="w-5 h-5 text-yellow-600" />
          <span className="text-sm font-medium text-yellow-800">Super Admin Access</span>
        </div>
      </div>

      <div className="glass-effect rounded-2xl shadow-lg overflow-hidden">
        <Tabs defaultValue="logs" className="w-full">
          <div className="border-b border-gray-200 bg-transparent overflow-x-auto">
            <TabsList className="w-full justify-start bg-transparent p-0 h-auto">
              {/* New Tabs */}
              <TabsTrigger 
                value="logs"
                className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 gap-2 whitespace-nowrap"
              >
                <FileClock className="w-4 h-4" />
                Activity Logs
              </TabsTrigger>
              <TabsTrigger 
                value="monitoring"
                className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 gap-2 whitespace-nowrap"
              >
                <Activity className="w-4 h-4" />
                API Monitoring
              </TabsTrigger>
              <TabsTrigger 
                value="health"
                className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 gap-2 whitespace-nowrap"
              >
                <Gauge className="w-4 h-4" />
                System Health
              </TabsTrigger>
              
              {/* Existing Tabs */}
              <TabsTrigger 
                value="roles"
                className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 gap-2 whitespace-nowrap"
              >
                <Users className="w-4 h-4" />
                User Roles
              </TabsTrigger>
              <TabsTrigger 
                value="api"
                className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 gap-2 whitespace-nowrap"
              >
                <Server className="w-4 h-4" />
                API Config
              </TabsTrigger>
              <TabsTrigger 
                value="whatsapp"
                className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700 data-[state=active]:border-b-2 data-[state=active]:border-green-600 rounded-none px-6 py-4 gap-2 whitespace-nowrap"
              >
                <Webhook className="w-4 h-4" />
                Webhooks
              </TabsTrigger>
            </TabsList>
          </div>

          {/* New Content Sections */}
          <TabsContent value="logs" className="p-6">
            <AdminActivityLogs />
          </TabsContent>

          <TabsContent value="monitoring" className="p-6">
            <AdminApiMonitoring />
          </TabsContent>

          <TabsContent value="health" className="p-6">
            <AdminSystemHealth />
          </TabsContent>

          {/* Existing Updated Sections */}
          <TabsContent value="roles" className="p-6 space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">Advanced User Permissions</h3>
                  <p className="text-sm text-gray-500">Manage role-based access control (RBAC)</p>
                </div>
                <Button variant="outline" size="sm">Invite New User</Button>
              </div>

              <div className="border rounded-xl overflow-hidden bg-white">
                <table className="w-full text-sm text-left">
                  <thead className="bg-gray-50 text-gray-700 font-semibold border-b">
                    <tr>
                      <th className="px-6 py-3">User</th>
                      <th className="px-6 py-3">Access Level</th>
                      <th className="px-6 py-3">Last Active</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {users.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="font-medium text-gray-900">{user.name}</div>
                          <div className="text-gray-500 text-xs">{user.email}</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <Select 
                              defaultValue={user.role} 
                              onValueChange={(val) => handleRoleChange(user.id, val)}
                            >
                              <SelectTrigger className="w-[140px] h-8 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="super_admin">Super Admin</SelectItem>
                                <SelectItem value="manager">Manager</SelectItem>
                                <SelectItem value="agent">Agent</SelectItem>
                                <SelectItem value="developer">Developer</SelectItem>
                                <SelectItem value="viewer">Viewer</SelectItem>
                              </SelectContent>
                            </Select>
                            <span className={`px-2 py-0.5 rounded text-[10px] border ${getRoleBadge(user.role)}`}>
                              {user.role.replace('_', ' ')}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-gray-500 text-xs">
                          {user.lastActive}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            user.status === 'active' 
                              ? 'bg-green-100 text-green-700' 
                              : 'bg-gray-100 text-gray-600'
                          }`}>
                            {user.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <Button variant="ghost" size="sm" className="text-red-600 h-8">Revoke</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="api" className="p-6 space-y-6">
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                    <Key className="w-5 h-5" /> System API Keys
                  </h3>
                  <Switch 
                    checked={!config.maintenanceMode} 
                    onCheckedChange={(c) => setConfig(p => ({...p, maintenanceMode: !c}))} 
                  />
                </div>
                
                <div className="space-y-4 bg-white/50 p-4 rounded-xl border border-gray-100">
                  <div>
                    <Label>Master API Key</Label>
                    <div className="flex gap-2 mt-1.5">
                      <Input value="sk_live_51Hz..." type="password" readOnly className="font-mono bg-gray-50" />
                      <Button variant="outline" size="icon"><Activity className="w-4 h-4" /></Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Used for server-to-server communication</p>
                  </div>

                  <div>
                    <Label>Rate Limit (Req/Min)</Label>
                    <Input 
                      name="apiRateLimit" 
                      value={config.apiRateLimit} 
                      onChange={handleChange} 
                      className="mt-1.5" 
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <Lock className="w-5 h-5" /> Security Policies
                </h3>
                
                <div className="space-y-4 bg-white/50 p-4 rounded-xl border border-gray-100">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Enforce 2FA for Admins</Label>
                      <p className="text-xs text-gray-500">Require two-factor auth for admin roles</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>IP Whitelisting</Label>
                      <p className="text-xs text-gray-500">Restrict admin access to specific IPs</p>
                    </div>
                    <Switch />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Audit Logging</Label>
                      <p className="text-xs text-gray-500">Log all administrative actions</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t">
              <Button onClick={() => handleSaveConfig('API')} className="whatsapp-gradient text-white">
                {loading ? 'Saving...' : 'Save Changes'}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="whatsapp" className="p-6 space-y-6">
             <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-bold text-blue-900">Webhook Configuration</h4>
                  <p className="text-sm text-blue-700 mt-1">
                    Changes here will affect real-time message delivery. Ensure your endpoint handles the challenge verification.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Callback URL</Label>
                    <Input 
                      name="webhookUrl" 
                      value={config.webhookUrl} 
                      onChange={handleChange}
                      className="mt-1.5 font-mono text-sm" 
                    />
                  </div>
                  <div>
                    <Label>Verify Token</Label>
                    <Input 
                      name="verifyToken" 
                      value={config.verifyToken} 
                      onChange={handleChange}
                      className="mt-1.5 font-mono text-sm" 
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label>App Secret Proof</Label>
                    <Input 
                      name="webhookSecret" 
                      value={config.webhookSecret} 
                      type="password"
                      onChange={handleChange}
                      className="mt-1.5 font-mono text-sm" 
                    />
                  </div>
                  <div>
                    <Label>System Access Token</Label>
                    <Input 
                      name="whatsappToken" 
                      value={config.whatsappToken} 
                      type="password"
                      onChange={handleChange}
                      className="mt-1.5 font-mono text-sm" 
                    />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => toast({ title: "Test Payload Sent", description: "Check your server logs." })}>
                  Test Webhook
                </Button>
                <Button onClick={() => handleSaveConfig('WhatsApp')} className="whatsapp-gradient text-white">
                  {loading ? 'Saving...' : 'Update Configuration'}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminControls;